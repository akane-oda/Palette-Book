const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());  // どこからでもリクエストOK
app.use(bodyParser.json());

// メール送信用の設定（直接Gmailの情報を記述）
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'palettebook01@gmail.com',  // 送信元のメールアドレス
        pass: 'jfxt vdxd wxau ezfr'  // Gmailのアプリパスワード
    }
});

// 認証コードを送信するAPI
app.post('/send-email', (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(400).send({ error: 'メールアドレスが必要です' });
    }

    const verificationCode = Math.floor(100000 + Math.random() * 900000); // 6桁の認証コード

    const mailOptions = {
        from: 'あなたのメール@gmail.com',
        to: email,
        subject: '認証コード',
        text: `あなたの認証コードは: ${verificationCode}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return res.status(500).send({ error: error.toString() });
        }
        res.status(200).send({ message: 'メール送信成功！', code: verificationCode });
    });
});

app.listen(3000, '0.0.0.0', () => {
    console.log('サーバー起動: http://0.0.0.0:3000');
});

