class DrawingApp {
    // DrawingAppクラスのコンストラクタ
    constructor() {
        this.layers = [];
        this.activeLayer = null;
        this.isDrawing = false;
        this.color = '#000000';
        this.size = 5;
        this.tool = 'pen';
        this.titleLayer = null; // タイトルレイヤーの参照を保持

        this.currentPage = 1;
        this.maxPages = 3; // 最大10ページまで作成できるように変更
        this.pages = {};
        this.isSaved = false;

        this.setupDOM();
        this.addEventListeners();
        this.addLayer();
        this.createTitleLayer(); // タイトルレイヤーを作成

        this.textInput = null;
        this.isDraggingText = false;
        this.activeText = null;
        this.textX = 0;
        this.textY = 0;

        this.storyText = '';
        this.setupTextArea();
        this.floodFill = this.floodFill.bind(this);

        this.history = [];
        this.historyStep = -1;

        // 最初の状態を保存
        this.saveCanvasState();

        // やり直し/進むボタンの初期状態を設定
        this.updateHistoryButtonStates();

        this.drawTitleAndAuthor(); // 題名と作者名を描画
    }

    // タイトルレイヤーを作成するメソッド
    createTitleLayer() {
        const canvas = document.createElement('canvas');
        canvas.width = this.canvasWidth;
        canvas.height = this.canvasHeight;

        // 最前面に配置するために非常に大きなz-indexを設定
        const topZIndex = 1000;
        canvas.style.zIndex = topZIndex;
        canvas.style.background = 'transparent';
        canvas.style.pointerEvents = 'none'; // マウスイベントを無視して下のレイヤーに伝達

        const ctx = canvas.getContext('2d', { alpha: true });

        this.titleLayer = {
            canvas: canvas,
            ctx: ctx,
            zIndex: topZIndex
        };

        this.canvasWrapper.appendChild(canvas);
    }

    // 題名と作者名を描画するメソッド（タイトルレイヤーに描画）
    // 題名と作者名を描画するメソッド（タイトルレイヤーに描画）- 修正版
    drawTitleAndAuthor() {
        // タイトルレイヤーが存在するか確認
        if (!this.titleLayer) return;

        // 前回の内容をクリア
        this.titleLayer.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);

        // 1ページ目の場合のみタイトルを描画
        // if (this.currentPage === 1) {
        //     // 題名を描画
        //     this.titleLayer.ctx.font = '24px Arial';
        //     this.titleLayer.ctx.fillStyle = '#333';
        //     this.titleLayer.ctx.fillText( storyTitle , 50, 50);

        //     // 作者名を描画
        //     this.titleLayer.ctx.font = '16px Arial';
        //     this.titleLayer.ctx.fillStyle = '#666';
        //     this.titleLayer.ctx.fillText('作者：' + authorName, 50, 80);

        //     // ページ表示
        //     this.titleLayer.ctx.font = '20px Arial';
        //     this.titleLayer.ctx.fillStyle = '#333';
        //     // this.titleLayer.ctx.fillText('ページ1', 50, 110);
        // }
    }



    // 履歴ボタンの状態を更新するメソッド
    updateHistoryButtonStates() {
        const undoButton = document.getElementById('undo-button');
        const redoButton = document.getElementById('redo-button');

        if (undoButton && redoButton) {
            undoButton.disabled = this.historyStep <= 0;
            redoButton.disabled = this.historyStep >= this.history.length - 1;
        }
    }

    setupTextArea() {
        const textarea = document.querySelector('.story-textarea');
        const textSaveButton = document.querySelector('.text-save-button');
        const voiceInputButton = document.querySelector('.voice-input-button');

        // テキストエリアの内容を保存
        textarea.addEventListener('input', (e) => {
            this.storyText = e.target.value;
            this.isSaved = false;
        });

        // 保存ボタンのクリックイベント
        textSaveButton.addEventListener('click', () => {
            this.saveStoryText();
        });

        // 音声入力ボタンのクリックイベント
        voiceInputButton.addEventListener('click', () => {
            this.startVoiceInput();
        });
    }

    startVoiceInput() {
    const textarea = document.querySelector('.story-textarea');
    const voiceButton = document.querySelector('.voice-input-button');

    if (this.isListening) {
        // すでに音声認識が開始されている場合、停止する
        this.recognition.stop();
        this.isListening = false;
        voiceButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" viewBox="0 0 24 24">
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
            <line x1="12" x2="12" y1="19" y2="22" />
        </svg>
    `; // マイクのアイコンを元に戻す // マイクのアイコンを元に戻す
        return;
    }

    // 音声認識を開始
    this.isListening = true;
    voiceButton.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" viewBox="0 0 24 24">
                    <rect x="6" y="6" width="12" height="12" rx="1" />
                </svg>
    `; // ボタンのアイコンを「停止」に変更

    if (!this.recognition) {
        this.recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        this.recognition.lang = 'ja-JP'; // 言語を日本語に設定
        this.recognition.interimResults = false; // 最終結果のみ取得（途中結果を表示しない）
        this.recognition.maxAlternatives = 1; // 認識された結果の候補を1つだけ取得
        this.recognition.continuous = true; // 連続認識を有効化（自動停止を防ぐ）

        // 音声認識の結果が得られたときの処理
        this.recognition.onresult = (event) => {
            const transcript = event.results[event.results.length - 1][0].transcript; // 最新の認識結果を取得
            textarea.value += transcript; // 認識結果をテキストエリアに追加
            this.storyText = textarea.value;
        };

        // エラーが発生した場合の処理
        this.recognition.onerror = (event) => {
            console.error('音声認識エラー:', event.error);
            this.isListening = false;
            voiceButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" viewBox="0 0 24 24">
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
            <line x1="12" x2="12" y1="19" y2="22" />
        </svg>
        `; // マイクのアイコンを元に戻す // エラー時にボタンを元の状態に戻す
        };

        // 音声の入力が一時停止したときに再開する
        this.recognition.onspeechend = () => {
            if (this.isListening) {
                this.recognition.start(); // 再度認識を開始
            }
        };

        // 音声認識が終了した場合、再開する（停止ボタンを押さない限り続行）
        this.recognition.onend = () => {
            if (this.isListening) {
                this.recognition.start(); // 再開
            } else {
                voiceButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" viewBox="0 0 24 24">
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
            <line x1="12" x2="12" y1="19" y2="22" />
        </svg>
            `; // マイクのアイコンを元に戻す // 停止時にボタンを元に戻す
            }
        };
    }

    this.recognition.start(); // 音声認識を開始
}

    saveStoryText() {
        // ボタンの視覚的フィードバック
        const textSaveButton = document.querySelector('.text-save-button');
        textSaveButton.style.background = '#FF0000';

        setTimeout(() => {
            textSaveButton.style.background = '#FFB6C1';
        }, 500);
    }


    // DOM要素の初期設定
    setupDOM() {
        this.canvasWrapper = document.getElementById('canvas-wrapper');
        this.layerList = document.getElementById('layer-list');
        this.activeLayerName = document.getElementById('active-layer-name');

        const container = document.querySelector('.canvas-container');
        this.canvasWidth = container.clientWidth;
        this.canvasHeight = container.clientHeight;

        // 背景レイヤーを作成
        this.backgroundCanvas = document.createElement('canvas');
        this.backgroundCanvas.width = this.canvasWidth;
        this.backgroundCanvas.height = this.canvasHeight;
        this.backgroundCanvas.style.zIndex = 1;
        this.backgroundCanvas.style.background = 'white';
        this.canvasWrapper.appendChild(this.backgroundCanvas);
    }

    // 現在のページを読み込む
    loadCurrentPage() {
        const pageData = this.pages[this.currentPage];

        // 既存のレイヤーをすべて削除
        while (this.layers.length > 0) {
            const layer = this.layers[0];
            layer.canvas.remove();
            this.layers.splice(0, 1);
        }

        // レイヤーリスト内の要素をすべて削除
        while (this.layerList.firstChild) {
            this.layerList.removeChild(this.layerList.firstChild);
        }

        // レイヤー1を新規作成
        this.addLayer();

        if (pageData) {
            // 保存されたページデータがある場合
            if (pageData.layersData && pageData.layersData.length > 0) {
                // 保存されていたレイヤー名を設定
                const firstLayerData = pageData.layersData[0];
                if (firstLayerData.name) {
                    this.activeLayer.name = firstLayerData.name;
                    // レイヤーリストのUIも更新
                    const layerNameElement = this.layerList.querySelector('.layer-name');
                    if (layerNameElement) layerNameElement.textContent = firstLayerData.name;
                    // インジケーターを更新
                    this.updateActiveLayerIndicator();
                }

                // レイヤーデータの読み込み
                const img = new Image();
                img.src = firstLayerData.canvasData;
                img.onload = () => {
                    this.activeLayer.ctx.drawImage(img, 0, 0);
                };

                // 文章の読み込み
                if (pageData.storyText) {
                    document.querySelector('.story-textarea').value = pageData.storyText;
                    this.storyText = pageData.storyText;
                } else {
                    document.querySelector('.story-textarea').value = '';
                    this.storyText = '';
                }
            } else {
                // レイヤーデータがない場合は空のキャンバス
                this.clearCanvas();

                // 文章の読み込み
                if (pageData.storyText) {
                    document.querySelector('.story-textarea').value = pageData.storyText;
                    this.storyText = pageData.storyText;
                } else {
                    document.querySelector('.story-textarea').value = '';
                    this.storyText = '';
                }
            }
        } else {
            // 新規ページの場合
            this.clearCanvas();
            document.querySelector('.story-textarea').value = '';
            this.storyText = '';
        }

        // 履歴リセット
        this.history = [];
        this.historyStep = -1;
        this.saveCanvasState(); // 初期状態を保存
        this.updateHistoryButtonStates();

        // ページ変更後にタイトルを描画
        this.drawTitleAndAuthor();
    }

    // キャンバスクリア
    clearCanvas() {
        this.layers.forEach(layer => {
            const ctx = layer.canvas.getContext('2d');
            ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height);
        });

        // タイトルレイヤーが存在する場合はクリア
        if (this.titleLayer) {
            this.titleLayer.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
        }
    }

    // 現在のページを保存
    // 現在のページを保存 - 修正版
    async saveCurrentPage() {
        // 各レイヤーのキャンバスデータを取得
        const layersData = this.layers.map(layer => ({
            id: layer.id,
            name: layer.name,
            canvasData: layer.canvas.toDataURL('image/png'),
            visible: layer.visible
        }));

        // タイトルレイヤーが存在する場合は、1ページ目だけタイトルを描画
        if (this.titleLayer) {
            this.titleLayer.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);

            // 1ページ目の場合のみタイトルを描画
            if (this.currentPage === 1) {
                this.drawTitleAndAuthor();
            }
        }

        // テキスト要素の位置とスタイル情報を取得
        const textElements = Array.from(document.querySelectorAll('.draggable-text')).map(el => ({
            text: el.textContent,
            left: el.style.left,
            top: el.style.top,
            fontSize: el.style.fontSize || '16px',
            color: el.style.color || '#000000',
            zIndex: el.style.zIndex || '1000'
        }));

        try {
            const response = await fetch('/save_page', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    page_number: this.currentPage,
                    layersData: layersData,
                    textElements: JSON.stringify(textElements),
                    storyText: this.storyText
                })
            });

            const result = await response.json();

            if (result.status === 'success') {
                // 保存したページのデータを更新
                this.pages[this.currentPage] = {
                    layersData: layersData,
                    textElements: textElements,
                    storyText: this.storyText
                };

                // 保存成功の視覚的フィードバック
                const saveButton = document.querySelector('.save-button');
                saveButton.style.background = '#FF0000';

                // 保存が完了したのでisSavedをtrueに設定
                this.isSaved = true;

                setTimeout(() => {
                    saveButton.style.background = '#FFB6C1';
                    this.checkAllPagesSaved();

                    // ページ自動遷移のロジック
                    if (this.currentPage < this.maxPages && !this.pages[this.currentPage + 1]) {
                        console.log('自動遷移: 次のページ(未保存)へ');
                        this.currentPage++;
                        this.loadCurrentPage();
                        this.updatePage();
                        this.isSaved = true; // 新規ページなので保存済み状態に設定
                    }
                }, 1000);
            } else {
                alert('保存に失敗しました。もう一度お試しください。');
            }
        } catch (error) {
            console.error('Error saving page:', error);
            alert('保存中にエラーが発生しました。');
        }
    }
    // キャンバスを画像として保存
    saveCanvas() {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = this.canvasWidth;
        tempCanvas.height = this.canvasHeight;
        const tempCtx = tempCanvas.getContext('2d');

        // 背景を白で描画
        tempCtx.fillStyle = '#ffffff';
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

        // レイヤーを順番に描画
        this.layers.forEach(layer => {
            if (layer.visible) {
                tempCtx.drawImage(layer.canvas, 0, 0);
            }
        });

        // タイトルレイヤーを最後に描画
        if (this.titleLayer) {
            tempCtx.drawImage(this.titleLayer.canvas, 0, 0);
        }

        const link = document.createElement('a');
        link.download = 'drawing.png';
        link.href = tempCanvas.toDataURL('image/png');
        link.click();
    }

    // イベントリスナーの設定
    addEventListeners() {
        // カラーピッカーのイベントリスナー
        const colorPicker = document.getElementById('color-picker');
        colorPicker.addEventListener('input', (e) => {
            this.color = e.target.value;
            // アクティブな色をリセット
            document.querySelectorAll('.color').forEach(btn => {
                btn.style.border = 'none';
            });
        });

        const undoButton = document.getElementById('undo-button');
        undoButton.addEventListener('click', () => this.undo());

        const redoButton = document.getElementById('redo-button');
        redoButton.addEventListener('click', () => this.redo());

        // レイヤー追加ボタン
        document.getElementById('add-layer').addEventListener('click', () => this.addLayer());

        // カラーパレットのイベントリスナー
        document.querySelectorAll('.color').forEach(button => {
            button.addEventListener('click', (e) => {
                this.color = e.target.style.backgroundColor;
                // アクティブな色を視覚的に示す
                document.querySelectorAll('.color').forEach(btn => {
                    btn.style.border = 'none';
                });
                e.target.style.border = '2px solid #666';
            });
        });

        // ツールボタン
        document.querySelectorAll('.tool').forEach(button => {
            button.addEventListener('click', (e) => {
                this.setTool(e.target.dataset.tool);
                document.querySelectorAll('.tool').forEach(btn => {
                    btn.classList.remove('active');
                });
                e.target.classList.add('active');
            });
        });

        // サイズボタン
        document.querySelectorAll('.size').forEach(button => {
            button.addEventListener('click', (e) => {
                const sizes = { 'small': 2, 'medium': 5, 'large': 10 };
                this.size = sizes[e.target.dataset.size];
                document.querySelectorAll('.size').forEach(btn => {
                    btn.classList.remove('active');
                });
                e.target.classList.add('active');
            });
        });

        // ページネーションのイベントリスナー
        const prevButton = document.querySelector('.pagination__arrow:first-child');
        const nextButton = document.querySelector('.pagination__arrow:last-child');

        prevButton.addEventListener('click', () => {
            if (this.currentPage > 1) {
                if (!this.isSaved) {
                    const confirmNav = confirm('現在のページが保存されていません。保存せずに移動しますか？');
                    if (!confirmNav) return;
                }
                this.currentPage--;
                this.loadCurrentPage();
                this.updatePage();
                this.isSaved = true; // 既存ページへの移動なのでtrueに設定
            } else {
                alert('最初のページです');
            }
        });

        nextButton.addEventListener('click', () => {
            // ページ変更時にタイトルレイヤーをクリア
            if (this.titleLayer) {
                this.titleLayer.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
            }
            if (this.currentPage < this.maxPages) {
                if (!this.isSaved) {
                    const confirmNav = confirm('現在のページが保存されていません。保存せずに移動しますか？');
                    if (!confirmNav) return;
                }
                this.currentPage++;
                this.loadCurrentPage();
                this.updatePage();
                this.isSaved = true; // 既存ページへの移動またはまっさらのページなのでtrueに設定
            } else {
                alert('最後のページです');
            }
        });

        // 完成ボタンのイベントリスナー
        const viewSummaryButton = document.getElementById('viewSummaryButton');
        viewSummaryButton.addEventListener('click', () => {
            if (!viewSummaryButton.disabled) {
                window.location.href = '/index3';
            }
        });

        // 保存ボタン
        document.querySelector('.save-button').addEventListener('click', () => this.saveCurrentPage());
    }

    // ツール選択
    setTool(toolName) {
        this.tool = toolName;
        document.querySelectorAll('.tool').forEach(button => {
            if (button.dataset.tool === toolName) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });

        // テキストツールが選択された時の処理
        if (toolName === 'text') {
            this.createTextInput();
        } else {
            this.removeTextInput();
        }
    }

    // テキスト入力UI作成
    createTextInput() {
        if (this.textInput) return;

        // テキスト入力用のdivを作成
        const textInputContainer = document.createElement('div');
        textInputContainer.style.cssText = `
    position: absolute;
    display: none;
    z-index: 1000;
`;

        // テキスト入力フィールド
        const input = document.createElement('input');
        input.type = 'text';
        input.style.cssText = `
    font-size: 16px;
    min-width: 200px;
`;

        // 確定ボタン
        const confirmButton = document.createElement('button');
        confirmButton.textContent = '確定';
        confirmButton.style.cssText = `
    margin-left: 5px;
    padding: 5px 10px;
    background: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
`;

        textInputContainer.appendChild(input);
        textInputContainer.appendChild(confirmButton);
        this.canvasWrapper.appendChild(textInputContainer);
        this.textInput = textInputContainer;

        // キャンバスクリックでテキスト入力を表示
        this.canvasWrapper.addEventListener('click', (e) => {
            if (this.tool === 'text') {
                const rect = this.canvasWrapper.getBoundingClientRect();
                this.textX = e.clientX - rect.left;
                this.textY = e.clientY - rect.top;

                textInputContainer.style.display = 'block';
                textInputContainer.style.left = `${this.textX}px`;
                textInputContainer.style.top = `${this.textY}px`;
                input.focus();
            }
        });

        // テキスト確定処理
        confirmButton.addEventListener('click', () => {
            if (input.value.trim()) {
                this.drawText(input.value, this.textX, this.textY);
                input.value = '';
                textInputContainer.style.display = 'none';
            }
        });

        // Enterキーでも確定
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && input.value.trim()) {
                this.drawText(input.value, this.textX, this.textY);
                input.value = '';
                textInputContainer.style.display = 'none';
            }
        });
    }

    // テキスト描画
    drawText(text, x, y) {
        if (!this.activeLayer) return;

        const textObj = {
            text: text,
            x: x,
            y: y,
            isDragging: false,
            layer: this.activeLayer
        };

        // テキストを描画
        this.activeLayer.ctx.font = '16px Arial';
        this.activeLayer.ctx.fillStyle = this.color;
        this.activeLayer.ctx.fillText(text, x, y);

        // ドラッグ可能なテキスト要素を作成
        const textElement = document.createElement('div');
        textElement.textContent = text;
        textElement.style.cssText = `
    position: absolute;
    left: ${x}px;
    top: ${y - 16}px;
    cursor: move;
    user-select: none;
    color: ${this.color};
    font: 16px Arial;
`;

        // ドラッグ機能の実装
        textElement.addEventListener('mousedown', (e) => {
            textObj.isDragging = true;
            this.activeText = textObj;

            const startX = e.clientX - x;
            const startY = e.clientY - y;

            const handleMouseMove = (moveEvent) => {
                if (textObj.isDragging) {
                    const newX = moveEvent.clientX - startX;
                    const newY = moveEvent.clientY - startY;

                    textElement.style.left = `${newX}px`;
                    textElement.style.top = `${newY - 16}px`;
                }
            };

            const handleMouseUp = () => {
                if (textObj.isDragging) {
                    textObj.isDragging = false;
                    this.activeText = null;

                    // 新しい位置にテキストを再描画
                    const rect = textElement.getBoundingClientRect();
                    const canvasRect = this.canvasWrapper.getBoundingClientRect();
                    const finalX = rect.left - canvasRect.left;
                    const finalY = rect.top - canvasRect.top + 16;

                    // 古いテキストを消去
                    this.activeLayer.ctx.clearRect(x - 1, y - 17,
                        this.activeLayer.ctx.measureText(text).width + 2, 20);

                    // 新しい位置に描画
                    this.activeLayer.ctx.fillText(text, finalX, finalY);

                    // テキスト要素を削除
                    textElement.remove();
                }
            };

            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        });

        this.canvasWrapper.appendChild(textElement);
    }

    // テキスト入力を非表示にする
    removeTextInput() {
        if (this.textInput) {
            this.textInput.style.display = 'none';
        }
    }

    // レイヤー追加
    addLayer() {
        const layerId = this.layers.length + 1;
        const canvas = document.createElement('canvas');
        canvas.width = this.canvasWidth;
        canvas.height = this.canvasHeight;

        // Fix: set new canvas z-index to be on top
        const canvasWrapper = document.getElementById('canvas-wrapper');
        const canvases = canvasWrapper.querySelectorAll("canvas");
        let maxZ = 0;
        canvases.forEach(c => {
            maxZ = Math.max(maxZ, parseInt(window.getComputedStyle(c).zIndex) || 0);
        });
        canvas.style.zIndex = maxZ + 1;
        canvas.style.background = 'transparent';

        const ctx = canvas.getContext('2d', { alpha: true });
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        const layer = {
            id: layerId,
            name: `レイヤー ${layerId}`,
            canvas: canvas,
            ctx: ctx,
            visible: true,
            zIndex: maxZ + 1
        };

        // 新しいレイヤーを配列の先頭に追加
        this.layers.unshift(layer);
        this.canvasWrapper.appendChild(canvas);
        this.createLayerListItem(layer);
        this.setActiveLayer(layer);

        this.setupCanvasListeners(canvas);
        this.updateLayerOrder(); // レイヤー順序を更新
    }

    // レイヤーリスト項目作成
    createLayerListItem(layer) {
        const item = document.createElement('div');
        item.className = 'layer-item';

        // 初期レイヤーの場合、activeクラスを追加
        if (layer.id === 1) {
            item.classList.add('active');
        }

        // レイヤー選択インジケーターを追加
        const indicator = document.createElement('div');
        indicator.className = 'layer-indicator';
        if (layer.id === 1) {
            indicator.classList.add('active');
        }
        item.appendChild(indicator);

        // レイヤー名表示用の要素を作成
        const layerNameSpan = document.createElement('span');
        layerNameSpan.className = 'layer-name';
        layerNameSpan.textContent = layer.name;
        layerNameSpan.style.marginRight = '5px';

        // コントロールグループを作成
        const controls = document.createElement('div');
        controls.className = 'layer-controls';

        // 編集ボタン追加
        const editButton = document.createElement('span');
        editButton.className = 'layer-edit';
        editButton.textContent = '✏️';
        editButton.style.cursor = 'pointer';
        editButton.title = 'レイヤー名を編集';

        // 表示・非表示ボタン
        const visibilitySpan = document.createElement('span');
        visibilitySpan.className = 'layer-visibility';
        visibilitySpan.textContent = '👁';
        visibilitySpan.style.marginRight = '5px';
        visibilitySpan.title = '表示/非表示の切り替え';

        // 削除ボタン
        const deleteSpan = document.createElement('span');
        deleteSpan.className = 'layer-delete';
        deleteSpan.textContent = '🗑';
        deleteSpan.style.marginLeft = '5px';
        deleteSpan.title = 'レイヤーを削除';

        // コントロールに各ボタンを追加
        controls.appendChild(visibilitySpan);
        controls.appendChild(editButton);
        controls.appendChild(deleteSpan);

        // レイヤーの順序を変更するボタンを追加
        const moveUpBtn = document.createElement('button');
        // moveUpBtn.textContent = '▲';
        moveUpBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const index = this.layers.indexOf(layer);
            if (index > 0) {
                // レイヤーリスト内での位置を取得
                const item = e.target.closest('.layer-item');
                const prev = item.previousElementSibling;
                if (prev) {
                    // DOMでの順序を変更
                    this.layerList.insertBefore(item, prev);
                    // レイヤーの順序とz-indexを更新
                    this.updateLayerOrder();
                }
            }
        });

        const moveDownBtn = document.createElement('button');
        // moveDownBtn.textContent = '▼';
        moveDownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const index = this.layers.indexOf(layer);
            if (index < this.layers.length - 1) {
                // レイヤーリスト内での位置を取得
                const item = e.target.closest('.layer-item');
                const next = item.nextElementSibling;
                if (next) {
                    // DOMでの順序を変更
                    this.layerList.insertBefore(next, item);
                    // レイヤーの順序とz-indexを更新
                    this.updateLayerOrder();
                }
            }
        });

        // コントロールに順序変更ボタンを追加
        controls.appendChild(moveUpBtn);
        controls.appendChild(moveDownBtn);

        // アイテムに要素を追加
        item.appendChild(layerNameSpan);
        item.appendChild(controls);

        // レイヤー名編集機能
        const editLayerName = () => {
            const input = document.createElement('input');
            input.type = 'text';
            input.value = layerNameSpan.textContent;
            input.style.width = '100px';
            input.style.border = '1px solid #ccc';
            input.style.borderRadius = '4px';
            input.style.padding = '2px';

            const saveLayerName = () => {
                const newName = input.value.trim();
                if (newName) {
                    layer.name = newName;
                    layerNameSpan.textContent = newName;
                    item.replaceChild(layerNameSpan, input);

                    // アクティブレイヤーの場合は、インジケーターも更新
                    if (this.activeLayer === layer) {
                        this.updateActiveLayerIndicator();
                    }
                } else {
                    item.replaceChild(layerNameSpan, input);
                }
            };

            input.addEventListener('blur', saveLayerName);
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    saveLayerName();
                }
            });

            item.replaceChild(input, layerNameSpan);
            input.focus();
        };

        // 編集ボタンのイベントリスナーを追加
        editButton.addEventListener('click', (e) => {
            e.stopPropagation(); // 親要素のクリックイベントが発生しないようにする
            editLayerName();
        });

        // 表示・非表示トグル
        visibilitySpan.addEventListener('click', (e) => {
            e.stopPropagation();
            layer.visible = !layer.visible;
            layer.canvas.style.display = layer.visible ? 'block' : 'none';
            visibilitySpan.textContent = layer.visible ? '👁' : '👁‍🗨';
            visibilitySpan.title = layer.visible ? '非表示にする' : '表示する';
        });

        // レイヤー削除
        deleteSpan.addEventListener('click', (e) => {
            e.stopPropagation();
            if (this.layers.length > 1) {
                const confirmDelete = confirm(`${layer.name}を削除しますか？`);
                if (confirmDelete) {
                    this.deleteLayer(layer);
                }
            } else {
                alert('最後のレイヤーは削除できません');
            }
        });

        // レイヤーアクティブ化
        item.addEventListener('click', () => {
            // 既存のアクティブ状態をリセット
            document.querySelectorAll('.layer-item').forEach(li => {
                li.classList.remove('active');
                li.querySelector('.layer-indicator').classList.remove('active');
            });

            // 新しいレイヤーをアクティブに
            item.classList.add('active');
            indicator.classList.add('active');

            this.setActiveLayer(layer);
        });

        // 昇順で並べるために、子要素の末尾に追加
        this.layerList.insertBefore(item, this.layerList.firstChild);
    }

    // アクティブレイヤーインジケーターの更新
    updateActiveLayerIndicator() {
        if (!this.activeLayer || !this.activeLayerName) return;

        this.activeLayerName.textContent = `(${this.activeLayer.name})`;

        // レイヤーリスト内のインジケーターも更新
        document.querySelectorAll('.layer-item').forEach(item => {
            const indicator = item.querySelector('.layer-indicator');
            const layerName = item.querySelector('.layer-name').textContent;

            if (this.activeLayer.name === layerName) {
                indicator.classList.add('active');
                item.classList.add('active');
            } else {
                indicator.classList.remove('active');
                item.classList.remove('active');
            }
        });
    }

    // キャンバスのイベントリスナー設定
    setupCanvasListeners(canvas) {
        const handleStart = (e) => {
            const event = e.touches ? e.touches[0] : e;
            this.startDrawing(event);
        };

        const handleMove = (e) => {
            const event = e.touches ? e.touches[0] : e;
            this.draw(event);
        };

        const handleEnd = () => {
            this.stopDrawing();
        };

        // マウスイベント
        canvas.addEventListener('mousedown', handleStart);
        canvas.addEventListener('mousemove', handleMove);
        canvas.addEventListener('mouseup', handleEnd);
        canvas.addEventListener('mouseout', handleEnd);

        // タッチイベント
        canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            handleStart(e);
        });
        canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            handleMove(e);
        });
        canvas.addEventListener('touchend', handleEnd);
    }

    // 塗りつぶしツール
    floodFill(startX, startY) {
        if (!this.activeLayer || !this.activeLayer.visible) return;

        const ctx = this.activeLayer.ctx;
        const imageData = ctx.getImageData(0, 0, this.canvasWidth, this.canvasHeight);
        const pixels = imageData.data;

        const startPos = (startY * this.canvasWidth + startX) * 4;
        const startR = pixels[startPos];
        const startG = pixels[startPos + 1];
        const startB = pixels[startPos + 2];
        const startA = pixels[startPos + 3];

        // 現在選択されている色を取得
        const fillColor = this.getRgbFromColor(this.color);
        const fillR = fillColor.r;
        const fillG = fillColor.g;
        const fillB = fillColor.b;
        const fillA = 255;

        const stack = [[startX, startY]];
        const visited = new Set();

        while (stack.length > 0) {
            const [x, y] = stack.pop();
            const pos = (y * this.canvasWidth + x) * 4;

            if (visited.has(`${x},${y}`)) continue;
            visited.add(`${x},${y}`);

            if (this.matchesStartColor(pixels[pos], pixels[pos + 1], pixels[pos + 2], pixels[pos + 3],
                startR, startG, startB, startA)) {
                pixels[pos] = fillR;
                pixels[pos + 1] = fillG;
                pixels[pos + 2] = fillB;
                pixels[pos + 3] = fillA;

                // 8方向のピクセルをチェック
                const directions = [
                    [-1, 0], [1, 0], [0, -1], [0, 1], // 上下左右
                    [-1, -1], [-1, 1], [1, -1], [1, 1] // 斜め
                ];

                for (const [dx, dy] of directions) {
                    const newX = x + dx;
                    const newY = y + dy;
                    if (newX >= 0 && newX < this.canvasWidth &&
                        newY >= 0 && newY < this.canvasHeight) {
                        stack.push([newX, newY]);
                    }
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
    }

    // RGB値を取得するヘルパーメソッド
    getRgbFromColor(color) {
        if (color.startsWith('#')) {
            return this.hexToRgb(color);
        } else if (color.startsWith('rgb')) {
            // rgb(r, g, b) 形式の文字列から数値を抽出
            const match = color.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
            if (match) {
                return {
                    r: parseInt(match[1]),
                    g: parseInt(match[2]),
                    b: parseInt(match[3])
                };
            }
        } else if (color === 'black') {
            return { r: 0, g: 0, b: 0 };
        } else if (color === 'red') {
            return { r: 255, g: 0, b: 0 };
        } else if (color === 'blue') {
            return { r: 0, g: 0, b: 255 };
        } else if (color === 'yellow') {
            return { r: 255, g: 255, b: 0 };
        } else if (color === 'green') {
            return { r: 0, g: 128, b: 0 };
        } else if (color === 'orange') {
            return { r: 255, g: 165, b: 0 };
        } else if (color === 'purple') {
            return { r: 128, g: 0, b: 128 };
        } else if (color === 'pink') {
            return { r: 255, g: 192, b: 203 };
        }

        // デフォルトは黒
        return { r: 0, g: 0, b: 0 };
    }

    // 色が一致するかチェックするヘルパーメソッド
    matchesStartColor(r, g, b, a, startR, startG, startB, startA) {
        // 許容誤差を大きくして、より柔軟に色の違いを許容する
        const tolerance = 50;
        return Math.abs(r - startR) <= tolerance &&
            Math.abs(g - startG) <= tolerance &&
            Math.abs(b - startB) <= tolerance &&
            Math.abs(a - startA) <= tolerance;
    }

    // 16進数のカラーコードをRGBに変換するヘルパーメソッド
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    // 描画開始
    startDrawing(e) {
        if (this.activeLayer && this.activeLayer.visible) {
            const canvas = this.activeLayer.canvas;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvas.width / rect.width;
            const scaleY = canvas.height / rect.height;

            const x = (e.clientX - rect.left) * scaleX;
            const y = (e.clientY - rect.top) * scaleY;

            if (this.tool === 'fill') {
                this.saveCanvasState(); // 塗りつぶし前に状態を保存
                this.floodFill(Math.floor(x), Math.floor(y));
                this.saveCanvasState(); // 塗りつぶし後に状態を保存
                return;
            }

            // 描画を開始する前に現在の状態を保存
            this.saveCanvasState();

            this.isDrawing = true;

            // コンテキストの準備
            this.activeLayer.ctx.beginPath();
            this.activeLayer.ctx.moveTo(x, y);

            if (this.tool === 'eraser') {
                this.activeLayer.ctx.globalCompositeOperation = 'destination-out';
                this.activeLayer.ctx.strokeStyle = 'rgba(0,0,0,1)';
            } else {
                this.activeLayer.ctx.globalCompositeOperation = 'source-over';
                this.activeLayer.ctx.strokeStyle = this.color;
            }

            // 線のスタイルを設定
            this.activeLayer.ctx.lineWidth = this.size;
            this.activeLayer.ctx.lineCap = 'round';
            this.activeLayer.ctx.lineJoin = 'round';

            // 最初の位置を保存
            this.activeLayer.ctx.lastX = x;
            this.activeLayer.ctx.lastY = y;
        }
    }

    // 描画中
    draw(e) {
        if (this.isDrawing && this.activeLayer && this.activeLayer.visible) {
            const canvas = this.activeLayer.canvas;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvas.width / rect.width;
            const scaleY = canvas.height / rect.height;

            const x = (e.clientX - rect.left) * scaleX;
            const y = (e.clientY - rect.top) * scaleY;

            // 最後の位置からの距離を計算
            const lastX = this.activeLayer.ctx.lastX || x;
            const lastY = this.activeLayer.ctx.lastY || y;
            const distance = Math.sqrt(
                Math.pow(x - lastX, 2) + Math.pow(y - lastY, 2)
            );

            // 線の間隔と太さに基づいて描画を制御
            const minDistance = Math.max(1, this.size / 2);
            if (distance < minDistance) return;

            // ベジェ曲線を使用して滑らかな線を描画
            this.activeLayer.ctx.beginPath();
            this.activeLayer.ctx.moveTo(lastX, lastY);

            // 中間点を計算して、よりスムーズな線を描画
            const midX = (lastX + x) / 2;
            const midY = (lastY + y) / 2;

            this.activeLayer.ctx.quadraticCurveTo(lastX, lastY, midX, midY);
            this.activeLayer.ctx.lineTo(x, y);

            // 線のスタイルを設定
            this.activeLayer.ctx.lineWidth = this.size;
            this.activeLayer.ctx.lineCap = 'round';
            this.activeLayer.ctx.lineJoin = 'round';

            // 描画
            this.activeLayer.ctx.stroke();

            // 最後の位置を更新
            this.activeLayer.ctx.lastX = x;
            this.activeLayer.ctx.lastY = y;
        }
    }

    // 描画終了
    stopDrawing() {
        if (this.activeLayer) {
            this.activeLayer.ctx.globalCompositeOperation = 'source-over';

            // 最後の座標をリセット
            this.activeLayer.ctx.lastX = undefined;
            this.activeLayer.ctx.lastY = undefined;

            // 最後のパスを閉じる
            this.activeLayer.ctx.closePath();

            // 描画終了後に状態を保存
            this.saveCanvasState();
        }
        this.isDrawing = false;
    }

    // アクティブレイヤーの設定
    setActiveLayer(layer) {
        this.activeLayer = layer;
        this.updateActiveLayerIndicator();
    }

    // レイヤー削除
    deleteLayer(layer) {
        const index = this.layers.indexOf(layer);
        if (index > -1) {
            this.layers.splice(index, 1);
            layer.canvas.remove();

            // レイヤーリストからアイテムを削除
            const layerItems = this.layerList.querySelectorAll('.layer-item');
            layerItems[index].remove();

            if (this.activeLayer === layer) {
                if (this.layers.length > 0) {
                    const newActiveLayer = this.layers[Math.max(0, index - 1)];
                    this.setActiveLayer(newActiveLayer);
                }
            }
            this.updateLayerOrder();
        }
    }

    // レイヤー順序更新
    updateLayerOrder() {
        // レイヤーリストを取得し、上から順にz-indexを設定
        const layerItems = Array.from(this.layerList.children);
        const layersInOrder = layerItems.map(item => {
            const layerName = item.querySelector('.layer-name').textContent;
            return this.layers.find(l => l.name === layerName);
        }).filter(layer => layer); // undefinedを除外

        // z-indexを更新
        // 最上位のレイヤーが最も大きいz-indexを持つように設定
        layersInOrder.forEach((layer, index) => {
            const zIndex = layersInOrder.length + 10 - index; // 逆順でz-indexを設定
            layer.zIndex = zIndex;
            layer.canvas.style.zIndex = zIndex;
        });

        // 順序変更後のレイヤー配列を更新
        this.layers = layersInOrder;

        // アクティブレイヤーのインジケーターを更新
        this.updateActiveLayerIndicator();
    }

    // レイヤーリストの順序を更新
    updateLayerListOrder() {
        const layerList = document.getElementById('layer-list');
        while (layerList.firstChild) {
            layerList.removeChild(layerList.firstChild);
        }
        this.layers.forEach(layer => {
            this.createLayerListItem(layer);
        });
    }

    // ページ表示の更新
    updatePage() {
        const pageText = document.querySelector('.pagination__text');
        pageText.textContent = `${this.currentPage}`;
        this.checkAllPagesSaved();
    }

    // 全ページの保存状態チェック
    checkAllPagesSaved() {
        const viewSummaryButton = document.getElementById('viewSummaryButton');
        const allPagesSaved = Object.keys(this.pages).length === this.maxPages;
        viewSummaryButton.disabled = !allPagesSaved;
    }

    // 履歴の保存
    saveCanvasState() {
        if (!this.activeLayer) return;

        // すべてのレイヤーの完全な状態をキャプチャ
        const layerStates = this.layers.map(layer => {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = this.canvasWidth;
            tempCanvas.height = this.canvasHeight;
            const tempCtx = tempCanvas.getContext('2d');

            // 各レイヤーの完全な内容をコピー
            tempCtx.drawImage(layer.canvas, 0, 0);

            return {
                layerId: layer.id,
                imageData: tempCanvas.toDataURL('image/png'),
                visible: layer.visible
            };
        });

        // 履歴管理
        this.history = this.history.slice(0, this.historyStep + 1);

        // 現在の状態を追加する前に、最後の状態と異なるかチェック
        const lastHistory = this.history[this.history.length - 1];
        const isStateChanged = !this.isStateEqual(lastHistory, layerStates);

        if (isStateChanged) {
            this.history.push(layerStates);
            this.historyStep++;
        }

        // 履歴の最大長を制限
        const MAX_HISTORY = 50;
        if (this.history.length > MAX_HISTORY) {
            this.history.shift();
            this.historyStep = this.history.length - 1;
        }

        // 履歴ボタンの状態を更新
        this.updateHistoryButtonStates();
    }

    // 状態の比較
    isStateEqual(prevState, currentState) {
        if (!prevState || prevState.length !== currentState.length) return false;

        return prevState.every((prevLayer, index) => {
            const currentLayer = currentState[index];
            return (
                prevLayer.layerId === currentLayer.layerId &&
                prevLayer.imageData === currentLayer.imageData &&
                prevLayer.visible === currentLayer.visible
            );
        });
    }

    // 履歴からの復元
    restoreCanvasState(layerStates) {
        // すべてのレイヤーをクリア
        this.layers.forEach(layer => {
            const ctx = layer.canvas.getContext('2d');
            ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height);
        });

        // 各レイヤーの状態を完全に復元
        layerStates.forEach(layerState => {
            const layer = this.layers.find(l => l.id === layerState.layerId);
            if (layer) {
                // レイヤーの可視性を復元
                layer.visible = layerState.visible;
                layer.canvas.style.display = layer.visible ? 'block' : 'none';

                // レイヤーの内容を復元
                const img = new Image();
                img.onload = () => {
                    const ctx = layer.canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                };
                img.src = layerState.imageData;
            }
        });

        // レイヤーリストの表示を更新
        this.updateLayerVisibility();
    }

    // レイヤーの可視性更新
    updateLayerVisibility() {
        const layerItems = document.querySelectorAll('.layer-item');
        layerItems.forEach(item => {
            const layerName = item.querySelector('.layer-name').textContent;
            const layer = this.layers.find(l => l.name === layerName);
            if (layer) {
                const visibilitySpan = item.querySelector('.layer-visibility');
                if (visibilitySpan) {
                    visibilitySpan.textContent = layer.visible ? '👁' : '👁‍🗨';
                    visibilitySpan.title = layer.visible ? '非表示にする' : '表示する';
                }
            }
        });
    }

    // 元に戻す
    undo() {
        if (this.historyStep > 0) {
            this.historyStep--;
            this.restoreCanvasState(this.history[this.historyStep]);
            this.updateHistoryButtonStates();
        }
    }

    // やり直し
    redo() {
        if (this.historyStep < this.history.length - 1) {
            this.historyStep++;
            this.restoreCanvasState(this.history[this.historyStep]);
            this.updateHistoryButtonStates();
        }
    }

    // 現在のページを読み込む
    // 現在のページを読み込む - 修正版
    loadCurrentPage() {
        const pageData = this.pages[this.currentPage];

        // タイトルレイヤーを明示的にクリアする処理を追加
        if (this.titleLayer) {
            this.titleLayer.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
        }

        // 既存のレイヤーをすべて削除
        while (this.layers.length > 0) {
            const layer = this.layers[0];
            layer.canvas.remove();
            this.layers.splice(0, 1);
        }

        // レイヤーリスト内の要素をすべて削除
        while (this.layerList.firstChild) {
            this.layerList.removeChild(this.layerList.firstChild);
        }

        // レイヤー1を新規作成
        this.addLayer();

        if (pageData) {
            // 保存されたページデータがある場合
            if (pageData.layersData && pageData.layersData.length > 0) {
                // 保存されていたレイヤー名を設定
                const firstLayerData = pageData.layersData[0];
                if (firstLayerData.name) {
                    this.activeLayer.name = firstLayerData.name;
                    // レイヤーリストのUIも更新
                    const layerNameElement = this.layerList.querySelector('.layer-name');
                    if (layerNameElement) layerNameElement.textContent = firstLayerData.name;
                    // インジケーターを更新
                    this.updateActiveLayerIndicator();
                }

                // レイヤーデータの読み込み
                const img = new Image();
                img.src = firstLayerData.canvasData;
                img.onload = () => {
                    this.activeLayer.ctx.drawImage(img, 0, 0);
                };

                // 文章の読み込み
                if (pageData.storyText) {
                    document.querySelector('.story-textarea').value = pageData.storyText;
                    this.storyText = pageData.storyText;
                }
            } else {
                // レイヤーデータがない場合は空のキャンバス
                this.clearCanvas();

                // 文章の読み込み
                if (pageData.storyText) {
                    document.querySelector('.story-textarea').value = pageData.storyText;
                    this.storyText = pageData.storyText;
                } else {
                    document.querySelector('.story-textarea').value = '';
                    this.storyText = '';
                }
            }
        } else {
            // 新規ページの場合
            this.clearCanvas();
            document.querySelector('.story-textarea').value = '';
            this.storyText = '';
        }

        // 履歴リセット
        this.history = [];
        this.historyStep = -1;
        this.saveCanvasState(); // 初期状態を保存
        this.updateHistoryButtonStates();

        // ページ変更後にタイトルを描画（1ページ目のみ）
        this.drawTitleAndAuthor();
    }

    // キャンバスクリア
    clearCanvas() {
        this.layers.forEach(layer => {
            const ctx = layer.canvas.getContext('2d');
            ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height);
        });
    }

    // 現在のページを保存
    async saveCurrentPage() {
        // 各レイヤーのキャンバスデータを取得
        const layersData = this.layers.map(layer => ({
            id: layer.id,
            name: layer.name, // レイヤー名を追加
            canvasData: layer.canvas.toDataURL('image/png'),
            visible: layer.visible
        }));


        this.drawTitleAndAuthor(); // 題名と作者名を描画

        // テキスト要素の位置とスタイル情報を取得
        const textElements = Array.from(document.querySelectorAll('.draggable-text')).map(el => ({
            text: el.textContent,
            left: el.style.left,
            top: el.style.top,
            fontSize: el.style.fontSize || '16px',
            color: el.style.color || '#000000',
            zIndex: el.style.zIndex || '1000'
        }));

        try {
            const response = await fetch('/save_page', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    page_number: this.currentPage,
                    layersData: layersData,
                    textElements: JSON.stringify(textElements),
                    storyText: this.storyText
                })
            });

            const result = await response.json();

            if (result.status === 'success') {
                // 保存したページのデータを更新
                this.pages[this.currentPage] = {
                    layersData: layersData,
                    textElements: textElements,
                    storyText: this.storyText
                };

                // 保存成功の視覚的フィードバック
                const saveButton = document.querySelector('.save-button');
                saveButton.style.background = '#FF0000';

                // 保存が完了したのでisSavedをtrueに設定
                this.isSaved = true;

                setTimeout(() => {
                    saveButton.style.background = '#FFB6C1';
                    this.checkAllPagesSaved();

                    // ページ自動遷移のロジック
                    // 条件1: 現在が最終ページでない
                    // 条件2: 次のページが未保存である
                    if (this.currentPage < this.maxPages && !this.pages[this.currentPage + 1]) {
                        console.log('自動遷移: 次のページ(未保存)へ');
                        this.currentPage++;
                        this.loadCurrentPage();
                        this.updatePage();
                        this.isSaved = true; // 新規ページなので保存済み状態に設定
                    }
                }, 1000);
            } else {
                alert('保存に失敗しました。もう一度お試しください。');
            }
        } catch (error) {
            console.error('Error saving page:', error);
            alert('保存中にエラーが発生しました。');
        }
    }

    // キャンバスを画像として保存
    saveCanvas() {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = this.canvasWidth;
        tempCanvas.height = this.canvasHeight;
        const tempCtx = tempCanvas.getContext('2d');

        // 背景を白で描画
        tempCtx.fillStyle = '#ffffff';
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

        // レイヤーを順番に描画
        this.layers.forEach(layer => {
            if (layer.visible) {
                tempCtx.drawImage(layer.canvas, 0, 0);
            }
        });

        const link = document.createElement('a');
        link.download = 'drawing.png';
        link.href = tempCanvas.toDataURL('image/png');
        link.click();
    }
}

// // レイヤー情報ポップアップのイベントリスナー
// document.addEventListener('DOMContentLoaded', () => {
//     const layerInfoBtn = document.getElementById('layer-info-btn');
//     const layerInfoPopup = document.getElementById('layer-info-popup');
//     const layerInfoCloseBtn = document.getElementById('layer-info-close');

//     if (layerInfoBtn && layerInfoPopup && layerInfoCloseBtn) {
//         // トグル関数
//         function toggleLayerInfo(event) {
//             event.stopPropagation(); // イベントの伝播を防止
//             layerInfoPopup.classList.toggle('active');
//         }

//         // イベントリスナーを追加
//         layerInfoBtn.addEventListener('click', toggleLayerInfo);
//         layerInfoCloseBtn.addEventListener('click', toggleLayerInfo);

//         // ドキュメント外クリックでポップアップを閉じる
//         document.addEventListener('click', (event) => {
//             if (layerInfoPopup.classList.contains('active') &&
//                 !layerInfoPopup.contains(event.target) &&
//                 event.target !== layerInfoBtn) {
//                 layerInfoPopup.classList.remove('active');
//             }
//         });
//     }
// });

document.addEventListener('DOMContentLoaded', () => {
    const layerInfoBtn = document.getElementById('layer-info-btn');
    const layerInfoPopup = document.getElementById('layer-info-popup');
    const layerInfoCloseBtn = document.getElementById('layer-info-close');

    if (layerInfoBtn && layerInfoPopup && layerInfoCloseBtn) {
        // ポップアップの表示位置を調整する関数
        function positionLayerInfoPopup() {
            const btnRect = layerInfoBtn.getBoundingClientRect(); // ボタンの位置取得
            layerInfoPopup.style.display = 'block';

            // 右側に表示（デフォルト）
            layerInfoPopup.style.top = `${btnRect.top + window.scrollY -110}px`;
            layerInfoPopup.style.left = `${btnRect.right + 60}px`;

            // 画面の右端を超えないようにする
            const popupRect = layerInfoPopup.getBoundingClientRect();
            if (popupRect.right > window.innerWidth) {
                // 右側が画面外なら、左側に配置
                layerInfoPopup.style.left = `${btnRect.left - popupRect.width - 10}px`;
            }
        }

        // トグル関数
        function toggleLayerInfo(event) {
            event.stopPropagation(); // イベントの伝播を防止
            if (layerInfoPopup.classList.contains('active')) {
                layerInfoPopup.classList.remove('active');
                layerInfoPopup.style.display = 'none';
            } else {
                positionLayerInfoPopup(); // 位置を更新
                layerInfoPopup.classList.add('active');
            }
        }

        // イベントリスナーを追加
        layerInfoBtn.addEventListener('click', toggleLayerInfo);
        layerInfoCloseBtn.addEventListener('click', toggleLayerInfo);

        // ドキュメント外クリックでポップアップを閉じる
        document.addEventListener('click', (event) => {
            if (layerInfoPopup.classList.contains('active') &&
                !layerInfoPopup.contains(event.target) &&
                event.target !== layerInfoBtn) {
                layerInfoPopup.classList.remove('active');
                layerInfoPopup.style.display = 'none';
            }
        });
    }
});


// DOMが読み込まれたら初期化
document.addEventListener('DOMContentLoaded', () => {
    const app = new DrawingApp();
});


console.log("Story Title:", storyTitle);
console.log("Author Name:", authorName);
