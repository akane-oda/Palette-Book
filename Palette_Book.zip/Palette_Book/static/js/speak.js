document.addEventListener("DOMContentLoaded", function () {
    let currentPage = 1;
    const pages = document.querySelectorAll(".page");
    const prevButton = document.getElementById("prev-button");
    const nextButton = document.getElementById("next-button");
    const totalPages = pages.length;

    let isSpeaking = false;
    let currentUtterance = null; // 追蹤當前朗讀的 utterance

    function cleanText(text) {
        return text.replace(/\s+/g, " ").trim();
    }

    function speakText(text, button) {
        let cleanStoryText = cleanText(text);
        console.log("📖 最終的に読み上げる内容:", cleanStoryText);

        if (!cleanStoryText) {
            alert("読み上げる内容がありません。");
            return;
        }

        // 如果正在朗讀，則停止
        if (isSpeaking) {
            speechSynthesis.cancel();
            isSpeaking = false;
            button.textContent = button.dataset.defaultText; // 恢復按鈕狀態
            console.log("🛑 朗読を停止しました");
            return;
        }

        currentUtterance = new SpeechSynthesisUtterance(cleanStoryText);
        currentUtterance.lang = "ja-JP";
        currentUtterance.rate = 1.0;
        currentUtterance.pitch = 1.0;

        currentUtterance.onend = function () {
            isSpeaking = false;
            button.textContent = button.dataset.defaultText;
        };

        speechSynthesis.speak(currentUtterance);
        isSpeaking = true;
        button.textContent = "⏹ 停止";
    }

    function updatePage() {
        pages.forEach(page => page.classList.remove("active"));

        const activePage = document.querySelector(`#page-${currentPage}`);
        if (activePage) {
            activePage.classList.add("active");

            setTimeout(() => {
                let newStoryTextElement = document.getElementById(`storyText-${currentPage}`);
            
                console.log("🔍 現在のページ:", currentPage);
                console.log("📄 newStoryTextElement:", newStoryTextElement ? newStoryTextElement.textContent.trim() : "null");
            
                if (newStoryTextElement) {
                    newStoryTextElement.style.display = "block"; // 正しいページのテキストを表示
                }
            }, 100);
            
            attachReadStoryButtonListener();
        }

        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages;
    }

    function attachReadStoryButtonListener() {
        let storyButton = document.getElementById(`readStoryButton-${currentPage}`);
        let storyTextElement = document.getElementById(`storyText-${currentPage}`);
    
        console.log("🎤 ボタン取得:", storyButton ? "成功" : "失敗");
        console.log("📖 ストーリーテキスト取得:", storyTextElement ? storyTextElement.textContent.trim() : "null");
    
        if (storyButton && storyTextElement) {
            storyButton.dataset.defaultText = "📖 読み上げる";
            storyButton.onclick = function () {
                let latestStoryText = storyTextElement.textContent.trim();
                console.log("📖 読み上げる内容:", latestStoryText);
                speakText(latestStoryText, storyButton);
            };
        }
    }

    function attachReadGeminiButtonListener() {
        let geminiButton = document.getElementById("readGeminiButton");
        let geminiTextElement = document.getElementById("gemini-content");

        if (!geminiButton) {
            console.warn("⚠️ 読み上げボタン (readGeminiButton) が見つかりません。");
            return;
        }

        if (!geminiTextElement) {
            console.warn("⚠️ Gemini の内容 (gemini-content) が見つかりません。");
            return;
        }

        geminiButton.dataset.defaultText = "💡 読み上げる";
        geminiButton.onclick = function () {
            setTimeout(() => {
                let latestGeminiText = geminiTextElement.textContent.trim();
                console.log("💡 読み上げる内容:", latestGeminiText);

                if (latestGeminiText) {
                    speakText(latestGeminiText, geminiButton);
                } else {
                    alert("Geminiの読み上げる内容がありません。");
                }
            }, 100);
        };
    }

    if (prevButton) {
        prevButton.addEventListener("click", function () {
            if (currentPage > 1) {
                currentPage--;
                updatePage();
            }
        });
    }

    if (nextButton) {
        nextButton.addEventListener("click", function () {
            if (currentPage < totalPages) {
                currentPage++;
                updatePage();
            }
        });
    }

    console.log("📄 初期 `storyText`:", document.getElementById("storyText") ? document.getElementById("storyText").textContent.trim() : "null");

    attachReadStoryButtonListener();
    attachReadGeminiButtonListener();
});

console.log("📖 修正後のストーリーテキスト取得:", document.getElementById("storyText") ? document.getElementById("storyText").textContent.trim() : "null");
