document.addEventListener("DOMContentLoaded", function () {
    let currentPage = 1;
    const pages = document.querySelectorAll(".page");
    const prevButton = document.getElementById("prev-button");
    const nextButton = document.getElementById("next-button");
    const totalPages = pages.length;

    let isSpeaking = false;
    let currentUtterance = null; // 現在の読み上げを管理する変数

    function cleanText(text) {
        return text.replace(/\s+/g, " ").trim(); // 連続する空白や改行を削除
    }

    function speakText(text, button) {
        let cleanStoryText = cleanText(text);
        console.log("📖 読み上げ内容:", cleanStoryText);

        if (!cleanStoryText) {
            alert("読み上げる内容がありません。");
            return;
        }

        // すでに読み上げ中なら停止する（中間停止）
        if (isSpeaking) {
            speechSynthesis.cancel();
            isSpeaking = false;
            button.textContent = "📖 読み上げる";
            return;
        }

        // 新しい読み上げを開始
        currentUtterance = new SpeechSynthesisUtterance(cleanStoryText);
        currentUtterance.lang = "ja-JP";
        currentUtterance.rate = 1.0;
        currentUtterance.pitch = 1.0;

        currentUtterance.onend = function () {
            isSpeaking = false;
            button.textContent = "📖 読み上げる";
        };

        speechSynthesis.speak(currentUtterance);
        isSpeaking = true;
        button.textContent = "⏹ 停止";
    }

    function updatePage() {
        pages.forEach(page => page.classList.remove("active"));

        const activePage = document.querySelector(`#page-${currentPage}`);
        activePage.classList.add("active");

        // 🟢 `storyText` を適切に更新
        document.querySelectorAll('.story-text-content').forEach((text) => {
            text.style.display = "none";
        });

        const currentStoryText = document.querySelector(`#storyText-${currentPage}`);
        if (currentStoryText) {
            currentStoryText.style.display = "block";
        }

        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages;

        // **ボタンのイベントを再設定**
        attachReadButtonListener();
    }

    function attachReadButtonListener() {
        let storyButton = document.querySelector(`#readStoryButton-${currentPage}`);
        if (storyButton) {
            storyButton.onclick = function () {
                setTimeout(() => {
                    let latestStoryTextElement = document.querySelector(`#storyText-${currentPage}`);
                    if (latestStoryTextElement) {
                        let latestStoryText = latestStoryTextElement.textContent.trim();
                        console.log("📖 読み上げる内容:", latestStoryText);
                        speakText(latestStoryText, storyButton);
                    } else {
                        console.warn("⚠ `storyText` が見つかりません！");
                    }
                }, 100);
            };
        } else {
            console.warn("⚠ `#readStoryButton` が見つかりません！");
        }
    }

    // ✅ ページ変更ボタンの処理
    if (prevButton) {
        prevButton.addEventListener("click", function () {
            if (currentPage > 1) {
                // **ページを変える前に読み上げを停止**
                speechSynthesis.cancel();
                isSpeaking = false;

                currentPage--;
                updatePage();
            }
        });
    }

    if (nextButton) {
        nextButton.addEventListener("click", function () {
            if (currentPage < totalPages) {
                // **ページを変える前に読み上げを停止**
                speechSynthesis.cancel();
                isSpeaking = false;

                currentPage++;
                updatePage();
            }
        });
    }

    // ✅ 初回ロード時に `#readStoryButton` のイベントを設定
    attachReadButtonListener();
});
