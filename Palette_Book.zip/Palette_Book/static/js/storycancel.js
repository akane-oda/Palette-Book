document.getElementById("deleteBookBtn").addEventListener("click", function() {
    const bookId = this.getAttribute("data-book-id"); // 確保獲取正確的 book ID
    console.log("削除する本のID:", bookId);  // 確認是否正確

    if (!bookId || bookId === "None") {
        alert("削除に失敗しました。本のIDが見つかりません。");
        return;
    }

    if (confirm("本当にこの絵本を削除しますか？")) {
        fetch(`/delete_book/${bookId}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                alert("絵本が削除されました！");
                window.location.href = "/home"; // ホームページへリダイレクト
            } else {
                alert("削除に失敗しました：" + data.message);
                console.error("削除エラー:", data.message);
            }
        })
        .catch(error => {
            alert("削除中にエラーが発生しました。");
            console.error("削除エラー:", error);
        });
    }
});