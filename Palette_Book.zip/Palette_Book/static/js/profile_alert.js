function checkProfile(event) {
    event.preventDefault(); // 通常のリンク遷移を防ぐ
    console.log("✅ checkProfile() が呼び出されました！"); // 確認用ログ

    fetch('/get_current_profile')
        .then(response => response.json())
        .then(data => {
            console.log("🔍 API のレスポンス: ", data);
            if (data.has_profile) {
                console.log("✅ プロフィールが選択されているので /start へ移動");
                window.location.href = '/start';
            } else {
                console.log("⚠️ プロフィール未選択、警告を表示");
                alert("⚠️ まだユーザーを選択していません！先にユーザーを追加してください。");
                window.location.href = '/look';
            }
        })
        .catch(error => {
            console.error("🚨 API エラー:", error);
            alert("エラーが発生しました。");
        });
}