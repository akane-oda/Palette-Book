import json
from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from flask_sqlalchemy import SQLAlchemy
import sqlite3
from datetime import datetime, timedelta
import logging
import google.generativeai as genai
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from oauthlib.oauth2 import WebApplicationClient
import requests
import json
import os
from collections import defaultdict

# from models import db, Book, Page, Layer, User, Profile


# Flaskアプリケーションのインスタンスを作成
app = Flask(__name__)

app.secret_key = "your_secret_key"  # セッションを使用するための秘密鍵を設定

# セッションの有効期限を30分に設定
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=3000)


# SQLiteデータベースの設定
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///books.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# SQLAlchemyのインスタンスを作成
db = SQLAlchemy(app)
genai.configure(api_key="AIzaSyD5Xx-18DiRdoYNXS2KqOf7rgQHY-6Df3U")


# ログの設定
logging.basicConfig(level=logging.DEBUG)

# ユーザー情報を保持するためのグローバル変数
current_user = None


class Book(db.Model):
    __tablename__ = "books"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    who = db.Column(db.String(100), nullable=False)
    where = db.Column(db.String(100), nullable=False)
    what = db.Column(db.String(100), nullable=False)
    genre = db.Column(db.String(50), nullable=False)
    author_id = db.Column(db.String(100), nullable=False)  # 作者のID
    author_name = db.Column(db.String(100), nullable=False)  # 作者の名前
    pages = db.relationship("Page", backref="book", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "who": self.who,
            "where": self.where,
            "what": self.what,
            "genre": self.genre,
            "author_id": self.author_id,
            "author_name": self.author_name,
        }


# 正しい順序でモデルを定義
class Page(db.Model):
    __tablename__ = "pages"
    id = db.Column(db.Integer, primary_key=True)
    page_number = db.Column(db.Integer, nullable=False)
    text_elements = db.Column(db.Text)
    story_text = db.Column(db.Text)
    book_id = db.Column(db.Integer, db.ForeignKey("books.id"), nullable=False)

    # リレーションシップも定義
    layers = db.relationship(
        "Layer", backref="page", lazy=True, cascade="all, delete-orphan"
    )

    def to_dict(self):
        return {
            "id": self.id,
            "page_number": self.page_number,
            "text_elements": self.text_elements,
            "story_text": self.story_text,
            "book_id": self.book_id,
        }


# Pageモデルの後にLayerモデルを定義
class Layer(db.Model):
    __tablename__ = "layers"
    id = db.Column(db.Integer, primary_key=True)
    layer_id = db.Column(db.Integer, nullable=False)
    canvas_data = db.Column(db.Text, nullable=False)
    visible = db.Column(db.Boolean, default=True)
    layer_name = db.Column(db.String(100), nullable=True)
    page_id = db.Column(db.Integer, db.ForeignKey("pages.id"), nullable=False)
    animation = db.Column(db.String(50), nullable=True)
    z_index = db.Column(db.Integer, nullable=False)


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)  # パスワード属性を追加


class Profile(db.Model):
    __tablename__ = "profiles"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    is_child = db.Column(db.Boolean, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    avatar = db.Column(
        db.String(100), default="default.png"
    )  # アバター画像のファイル名を追加


# データベースのテーブルを作成
with app.app_context():
    db.create_all()


def get_books():
    conn = sqlite3.connect("books.db")  # データベースファイル名を統一
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM books")
    books = cursor.fetchall()
    conn.close()
    return books


@app.route("/book_detail")
def book_detail_view():
    books = get_books()
    return render_template("book_detail.html", books=books)


#! ******************************************************************************************************
# ランダムな絵本ページを表示するエンドポイント
@app.route("/chara")
def chara():
    # データベースから全ての本を取得
    books = Book.query.all()

    # 各本のページ1~10を取得してプールに入れる
    all_pages = []

    for book in books:
        # ページ1~10を取得（存在する場合）
        pages = Page.query.filter(
            Page.book_id == book.id, Page.page_number >= 1, Page.page_number <= 10
        ).all()

        for page in pages:
            # 各ページのレイヤー情報を取得（z_indexでソート）
            layers = (
                Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index).all()
            )

            # レイヤーデータを整形
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                    "name": layer.layer_name,
                }
                for layer in layers
            ]

            # ページデータを整形して追加
            page_data = {
                "book_id": book.id,
                "book_title": book.title,
                "page_number": page.page_number,
                "story_text": page.story_text,
                "text_elements": page.text_elements,
                "layers": layers_data,
            }

            # キャンバスデータが存在するページのみ追加
            if any(layer["canvasData"] for layer in layers_data):
                all_pages.append(page_data)

    # ページがなければメッセージを表示
    if not all_pages:
        return render_template(
            "chara.html",
            error_message="表示できるページがありません。本を作成してください。",
        )

    # ランダムでページを選択
    random_page = random.choice(all_pages) if all_pages else None

    # デバッグ用
    if random_page:
        print(
            f"Selected page {random_page['page_number']} from book '{random_page['book_title']}'"
        )

    # ページをテンプレートに渡す
    return render_template("chara.html", page=random_page)


# 5. Update the chara_random route:
@app.route("/chara_random")
def chara_random():
    # データベースから全ての本を取得
    books = Book.query.all()

    # 各本のページ1を取得してプールに入れる
    all_pages = []

    for book in books:
        # ページ1を取得（存在する場合）
        page = Page.query.filter_by(book_id=book.id, page_number=1).first()

        if page:
            # 各ページのレイヤー情報を取得（z_indexでソート）
            layers = (
                Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index).all()
            )

            # レイヤーデータを整形
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                    "name": layer.layer_name,
                }
                for layer in layers
            ]

            # ページデータを整形して追加
            page_data = {
                "book_id": book.id,
                "book_title": book.title,
                "page_number": page.page_number,
                "story_text": page.story_text,
                "text_elements": page.text_elements,
                "layers": layers_data,
            }

            # キャンバスデータが存在するページのみ追加
            if any(layer["canvasData"] for layer in layers_data):
                all_pages.append(page_data)

    # ページがなければメッセージを表示
    if not all_pages:
        return render_template(
            "chara_random.html",
            error_message="表示できるページがありません。本を作成してください。",
        )

    # ページをテンプレートに渡す
    return render_template("chara_random.html", pages=all_pages)


@app.route("/")
def home():
    return redirect(url_for("login_page"))


@app.route("/login_page")
def login_page():
    return render_template("login.html")


@app.route("/try")
def try1():
    return render_template("try.html")


@app.route("/settings")
def settings():
    global current_user
    if not current_user:
        return redirect(url_for("login_page"))
    return render_template("settings.html", user=current_user)


@app.route("/select_profile", methods=["POST"])
def select_profile():
    global current_user
    if not current_user:
        return jsonify({"success": False})

    data = request.get_json()
    profile_name = data.get("name")

    profile = Profile.query.filter_by(
        name=profile_name, user_id=current_user["id"]
    ).first()
    if profile:
        current_user["selected_profile_name"] = profile.name
        return jsonify({"success": True})

    return jsonify({"success": False})


@app.route("/logout")
def logout():
    global current_user
    current_user = None
    return redirect(url_for("login_page"))


@app.route("/delete_account", methods=["POST"])
def delete_account():
    global current_user
    if not current_user:
        return jsonify({"success": False, "message": "ユーザーが見つかりません"})

    try:
        user_id = current_user["id"]

        # ユーザーが作成した絵本を取得
        books = Book.query.filter_by(author_id=user_id).all()

        # 絵本に関連するページとレイヤーを削除
        for book in books:
            pages = Page.query.filter_by(book_id=book.id).all()
            for page in pages:
                Layer.query.filter_by(page_id=page.id).delete()
                db.session.delete(page)
            db.session.delete(book)

        # ユーザーのプロフィールを削除
        Profile.query.filter_by(user_id=user_id).delete()

        # ユーザーを削除
        User.query.filter_by(id=user_id).delete()

        db.session.commit()
        current_user = None
        return jsonify({"success": True})
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting account: {e}")
        return jsonify(
            {"success": False, "message": "アカウントの削除中にエラーが発生しました"}
        )


@app.route("/manual_login", methods=["POST"])
def manual_login():
    global current_user
    email = request.form["email"]
    password = request.form["password"]
    user = User.query.filter_by(email=email).first()

    if user and user.password == password:
        current_user = {
            "id": user.id,
            "name": user.name,
            "email": user.email,
        }
        last_profile = (
            Profile.query.filter_by(user_id=user.id).order_by(Profile.id.desc()).first()
        )
        if last_profile:
            current_user["selected_profile_name"] = last_profile.name
            current_user["selected_profile_is_child"] = last_profile.is_child
        return redirect(url_for("home_page"))
    else:
        error = "メールアドレスまたはパスワードが間違っています"
        return render_template("login.html", error=error)


# homeページも同様に修正
@app.route("/home")
def home_page():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    profile_name = current_user.get("selected_profile_name")

    if not profile_name:
        profile = (
            Profile.query.filter_by(user_id=current_user["id"])
            .order_by(Profile.id.desc())
            .first()
        )
        if profile:
            profile_name = profile.name
            current_user["selected_profile_name"] = profile_name
        else:
            profile_name = "未定"

    books = (
        Book.query.filter_by(author_name=profile_name).order_by(Book.id.desc()).all()
    )

    # JSON に変換可能なリストを作成
    books_data = []
    for book in books:
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_dict = {}

        for page in pages:
            # z-indexの降順に取得
            layers = (
                Layer.query.filter_by(page_id=page.id)
                .order_by(Layer.z_index.desc())
                .all()
            )
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                }
                for layer in layers
            ]

            pages_dict[page.page_number] = {
                "layersData": layers_data,
                "textElements": page.text_elements,
                "storyText": page.story_text,
            }

        books_data.append({"book": book_dict, "pages": pages_dict})

    return render_template("home.html", books=books_data, name=profile_name)


# Add this route to your app.py file


# layer_pageルートも修正
@app.route("/layer")
def layer_page():
    """
    Display a page showing all available books with their layers
    """
    books = Book.query.order_by(Book.id.desc()).all()
    books_with_layers = []

    for book in books:
        # 本の基本情報を辞書形式で作成
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        # 本のページ情報を取得
        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_with_layers = []

        for page in pages:
            # z-indexの降順に取得
            layers = (
                Layer.query.filter_by(page_id=page.id)
                .order_by(Layer.z_index.desc())
                .all()
            )

            # レイヤーごとのデータを整形
            layers_data = []
            for layer in layers:
                layer_data = {
                    "id": layer.id,
                    "layer_id": layer.layer_id,
                    "canvas_data": layer.canvas_data,
                    "visible": layer.visible,
                    "name": layer.layer_name or f"レイヤー {layer.layer_id}",
                    "animation": layer.animation,
                }
                layers_data.append(layer_data)

            # ページ情報を辞書に格納
            if layers_data:  # レイヤーがあるページのみ追加
                page_dict = {
                    "page_number": page.page_number,
                    "story_text": page.story_text,
                    "layers": layers_data,
                }
                pages_with_layers.append(page_dict)

        # ページがある本のみ追加
        if pages_with_layers:
            book_dict["pages"] = pages_with_layers
            books_with_layers.append(book_dict)

    return render_template("layer.html", books=books_with_layers)


@app.route("/save_profile", methods=["POST"])
def save_profile():
    # グローバルユーザー情報を使用
    global current_user

    # ログインしていない場合はログインページにリダイレクト
    if not current_user:
        return redirect(url_for("login"))

    try:
        # フォームから名前を取得
        name = request.form["name"]

        # チェックボックスの値を確認（子供プロフィールかどうか）
        is_child = request.form.get("is_child") == "on"

        # アバター情報を取得（デフォルトは'default.png'）
        avatar = request.form.get("avatar", "default.png")

        # 新しいプロフィールを作成
        new_profile = Profile(
            name=name,  # プロフィール名
            is_child=is_child,  # 子供プロフィールかどうかのフラグ
            user_id=current_user["id"],  # 現在のユーザーのID
            avatar=avatar,  # アバター画像のファイル名
        )

        # データベースに新しいプロフィールを追加して保存
        db.session.add(new_profile)
        db.session.commit()

        # 現在のユーザー情報を更新
        current_user["selected_profile_name"] = name
        current_user["selected_profile_is_child"] = is_child

        # プロフィール保存後に look ページにリダイレクト
        return redirect(url_for("look"))

    except Exception as e:
        # エラーが発生した場合はデータベースのセッションをロールバック
        db.session.rollback()

        # エラーをコンソールに出力
        print(f"プロフィール保存中にエラーが発生しました: {e}")

        # エラーメッセージを表示
        return "プロフィールの保存に失敗しました", 500


@app.route("/profile")
def profile():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    author_id = current_user["id"]
    books = Book.query.filter_by(author_id=author_id).order_by(Book.id.desc()).all()
    books_data = []

    for book in books:
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_dict = {}

        for page in pages:
            layers = Layer.query.filter_by(page_id=page.id).all()
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                }
                for layer in layers
            ]

            pages_dict[page.page_number] = {
                "layersData": layers_data,
                "textElements": page.text_elements,
                "storyText": page.story_text,
            }

        books_data.append({"book": book_dict, "pages": pages_dict})

    return render_template("profile.html", books=books_data, name=current_user["name"])


@app.route("/profile_kids")
def profile_kids():
    """
    現在ログインしているユーザーのプロフィールを取得し、profile_kids.html に渡す
    """
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    # ユーザーのプロフィールを取得
    profile = Profile.query.filter_by(user_id=current_user["id"]).first()

    # プロフィールがない場合、新規作成
    # if not profile:
    #     profile = Profile(
    #         name="新しいプロファイル",
    #         is_child=True,  # デフォルトで子供のプロファイル
    #         user_id=current_user["id"],
    #         avatar="default.png"  # デフォルトのアバター
    #     )
    #     db.session.add(profile)
    #     db.session.commit()

    return render_template("profile_kids.html", profile=profile)


@app.route("/profile_edit")
def profile_edit():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    profiles = Profile.query.filter_by(user_id=current_user["id"]).all()
    return render_template("profile_edit.html", profiles=profiles)


@app.route("/delete_profile/<int:profile_id>", methods=["DELETE"])
def delete_profile(profile_id):
    global current_user
    if not current_user:
        return jsonify({"success": False, "message": "ユーザーが見つかりません"})

    # 現在のユーザーのプロフィール数を確認
    profile_count = Profile.query.filter_by(user_id=current_user["id"]).count()

    # 最後の1つのプロフィールは削除できない
    if profile_count <= 1:
        return jsonify(
            {
                "success": False,
                "message": "これ以上プロフィールを削除できません（最低1つ必要です）",
            }
        )

    profile = Profile.query.filter_by(id=profile_id, user_id=current_user["id"]).first()
    if profile:
        try:
            # このプロフィールが作成した本を取得
            books = Book.query.filter_by(author_name=profile.name).all()

            # 関連するページとレイヤーを削除
            for book in books:
                pages = Page.query.filter_by(book_id=book.id).all()
                for page in pages:
                    Layer.query.filter_by(page_id=page.id).delete()
                    db.session.delete(page)
                db.session.delete(book)

            # プロフィールを削除
            db.session.delete(profile)
            db.session.commit()

            # 削除後に別のプロフィールを選択する
            remaining_profiles = Profile.query.filter_by(
                user_id=current_user["id"]
            ).all()
            if remaining_profiles:
                current_user["selected_profile_name"] = remaining_profiles[0].name
            else:
                current_user["selected_profile_name"] = (
                    None  # これは実際には発生しない（最低1つは残る）
                )

            return jsonify({"success": True})
        except Exception as e:
            db.session.rollback()
            return jsonify(
                {
                    "success": False,
                    "message": "プロフィール削除中にエラーが発生しました: " + str(e),
                }
            )
    else:
        return jsonify({"success": False, "message": "プロフィールが見つかりません"})


@app.route("/rename_profile/<int:profile_id>", methods=["PUT"])
def rename_profile(profile_id):
    global current_user
    if not current_user:
        return jsonify({"success": False, "message": "ユーザーが見つかりません"})

    data = request.get_json()
    new_name = data.get("name")

    # 名前が空の時のチェック
    if not new_name.strip():
        return jsonify({"success": False, "message": "名前を入力してください"})

    profile = Profile.query.filter_by(id=profile_id, user_id=current_user["id"]).first()

    if profile:
        try:
            # 古い名前を保存
            old_name = profile.name

            # プロフィール名を更新
            profile.name = new_name

            # このプロフィールが作成した本の著者名も更新
            books = Book.query.filter_by(
                author_name=old_name, author_id=current_user["id"]
            ).all()
            for book in books:
                book.author_name = new_name

            # 変更をコミット
            db.session.commit()

            # `current_user` を更新
            current_user["selected_profile_name"] = new_name

            return jsonify({"success": True})
        except Exception as e:
            db.session.rollback()
            print(f"エラー: {e}")
            return jsonify(
                {"success": False, "message": "データベースの更新に失敗しました"}
            )
    else:
        return jsonify({"success": False, "message": "プロフィールが見つかりません"})


#! ******************************************************************************************************
@app.route("/look")
def look():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    # すべてのプロフィールを取得（現在のユーザーのプロフィールのみ）
    profiles = Profile.query.filter_by(user_id=current_user["id"]).all()

    # すべての本を取得（プロフィール制限なし）
    books = Book.query.order_by(Book.id.desc()).all()
    books_data = []

    for book in books:
        # 本の基本情報を辞書形式で作成
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        # 本のページ情報を取得
        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_dict = {}

        for page in pages:
            # 各ページのレイヤー情報を取得（z_indexでソート）
            layers = (
                Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index).all()
            )
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                }
                for layer in layers
            ]

            # ページ情報を辞書に格納
            pages_dict[page.page_number] = {
                "layersData": layers_data,
                "textElements": page.text_elements,
                "storyText": page.story_text,
            }

        # 本とそのページ情報をbooks_dataに追加
        books_data.append({"book": book_dict, "pages": pages_dict})

    # すべての本とプロフィールを表示するテンプレートにデータを渡す
    return render_template(
        "look.html", books=books_data, profiles=profiles, user=current_user
    )


# スタートページのルート
@app.route("/start", methods=["GET", "POST"])
def start():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    profile_name = current_user.get("selected_profile_name")
    if not profile_name or profile_name == "未定":
        return redirect(url_for("profile"))

    if request.method == "POST":
        try:
            data = request.get_json()

            # デバッグ用のログ出力
            app.logger.info(f"Received data: {data}")
            print(f"Received data: {data}")  # コンソール出力も追加

            # 新しい本を作成するときに作者情報を追加
            new_book = Book(
                who=data["who"],
                where=data["where"],
                what=data["what"],
                title=data.get("title", "無題の本"),  # タイトルがない場合のデフォルト値
                genre=data.get("genre", "未分類"),  # ジャンルがない場合のデフォルト値
                author_id=current_user["id"],
                author_name=profile_name,
            )

            db.session.add(new_book)
            db.session.commit()

            return jsonify({"status": "success", "book_id": new_book.id})
        except Exception as e:
            # エラーのロギング
            app.logger.error(f"Error in start route: {e}")
            print(f"Error in start route: {e}")  # コンソール出力

            # エラー発生時にロールバック
            db.session.rollback()

            return jsonify({"status": "error", "message": str(e)}), 500

    # GETリクエストの場合
    return render_template("start.html")


# ? ******************************************************************************************************
# インデックスページのルート
@app.route("/index")
def index():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    # 選択されたプロフィール名を使用
    profile_name = current_user.get("selected_profile_name", current_user["name"])

    book = Book.query.order_by(Book.id.desc()).first()
    return render_template(
        "index.html",
        story_title=book.title if book else "",
        name=profile_name,  # ここを修正
        who=book.who if book else "",
        where=book.where if book else "",
        what=book.what if book else "",
    )


# ? ******************************************************************************************************


#! ******************************************************************************************************
@app.route("/check")
def check():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    book = Book.query.order_by(Book.id.desc()).first()
    return render_template(
        "check.html",
        story_title=book.title if book else "",
        name=current_user["name"],
        who=book.who if book else "",
        where=book.where if book else "",
        what=book.what if book else "",
    )


@app.route("/get_page_data")
def get_page_data():
    global current_user
    if not current_user:
        return jsonify({"status": "error", "message": "ログインが必要です"})

    page_number = request.args.get("page", 1, type=int)

    # 最新の本を取得
    book = Book.query.order_by(Book.id.desc()).first()
    if not book:
        return jsonify({"status": "error", "message": "本が見つかりません"})

    # ページデータを取得
    page = Page.query.filter_by(book_id=book.id, page_number=page_number).first()
    if not page:
        return jsonify({"status": "success", "layersData": [], "storyText": ""})

    # レイヤーデータを取得
    layers = Layer.query.filter_by(page_id=page.id).all()
    layers_data = [
        {"canvasData": layer.canvas_data, "layerName": layer.layer_name}
        for layer in layers
    ]

    return jsonify(
        {
            "status": "success",
            "layersData": layers_data,
            "storyText": page.story_text,
        }
    )


@app.route("/get_total_pages")
def get_total_pages():
    # 最新の本を取得
    book = Book.query.order_by(Book.id.desc()).first()
    if not book:
        return jsonify({"status": "error", "message": "本が見つかりません"})

    # ページ数を取得
    total_pages = Page.query.filter_by(book_id=book.id).count()
    return jsonify({"status": "success", "total_pages": total_pages})


@app.route("/submit_story", methods=["POST"])
def submit_story():
    global current_user
    if not current_user:
        return jsonify({"status": "error", "message": "ログインが必要です"})

    data = request.get_json()

    # 最新の本を取得して完成としてマーク
    book = Book.query.order_by(Book.id.desc()).first()
    if not book:
        return jsonify({"status": "error", "message": "本が見つかりません"})

    try:
        book.is_completed = True
        book.completed_at = datetime.now()
        db.session.commit()

        return jsonify({"status": "success"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)})


@app.route("/edit")
def edit():
    """既存のページを編集するためのリダイレクト"""
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    return redirect(url_for("index"))


#! ******************************************************************************************************


# タイトル設定のルート
@app.route("/set_title", methods=["POST"])
def set_title():
    data = request.get_json()
    app.logger.debug(f"Received data: {data}")
    print(f"Received data: {data}")  # デバッグ用のprint文
    who = data["who"]
    where = data["where"]
    what = data["what"]
    title = data["title"]
    genre = data["genre"]

    new_book = Book(who=who, where=where, what=what, title=title, genre=genre)

    try:
        db.session.add(new_book)
        db.session.commit()
        print(f"Book created: {new_book}")  # デバッグ用のprint文
        return jsonify({"status": "success", "book_id": new_book.id})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error: {e}")
        print(f"Error: {e}")  # デバッグ用のprint文
        return jsonify({"status": "error", "message": str(e)}), 500


# app.pyのsave_pageルートを修正
@app.route("/save_page", methods=["POST"])
def save_page():
    data = request.json
    page_number = data["page_number"]
    layers_data = data["layersData"]
    text_elements = json.dumps(data.get("textElements", []))
    story_text = data.get("storyText", "")

    book = Book.query.order_by(Book.id.desc()).first()

    page = Page.query.filter_by(book_id=book.id, page_number=page_number).first()

    if not page:
        page = Page(
            page_number=page_number,
            text_elements=text_elements,
            story_text=story_text,
            book_id=book.id,
        )
        db.session.add(page)
        db.session.commit()

    # 既存のレイヤーを削除
    Layer.query.filter_by(page_id=page.id).delete()

    # 新しいレイヤーを追加
    for i, layer_data in enumerate(layers_data):
        layer = Layer(
            layer_id=layer_data["id"],
            canvas_data=layer_data["canvasData"],
            visible=layer_data["visible"],
            layer_name=layer_data.get("name", f"レイヤー {layer_data['id']}"),
            page_id=page.id,
            z_index=i,  # z_indexを追加
        )
        db.session.add(layer)

    try:
        db.session.commit()
        return jsonify({"status": "success"})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error saving page: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/save_animation", methods=["POST"])
def save_animation():

    data = request.json
    book = Book.query.order_by(Book.id.desc()).first()

    print(f"data :{data}")
    print(f"book :{book}")

    for page_number, layers in data.items():
        page = Page.query.filter_by(book_id=book.id, page_number=page_number).first()
        if page:
            for layer_data in layers:
                layer = Layer.query.filter_by(
                    page_id=page.id, layer_id=layer_data["layerId"]
                ).first()
                print(f"layer :{layer}")
                if layer:
                    layer.animation = layer_data["animation"]

    try:
        db.session.commit()
        return jsonify({"status": "success"})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error saving animation: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


# Update all routes that create layers_data to include z_index
# Example for one route:


@app.route("/read")
def read():
    global current_user
    if not current_user:
        return redirect(url_for("login"))

    book = Book.query.order_by(Book.id.desc()).first()
    pages = Page.query.filter_by(book_id=book.id).all()

    pages_dict = {}
    all_story_text = ""
    for page in pages:
        # ここでz-indexの降順（大きい順）に並べ替え
        layers = (
            Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index.desc()).all()
        )

        # z-indexを含むデータを送信
        layers_data = [
            {
                "layerId": layer.layer_id,
                "canvasData": layer.canvas_data,
                "visible": layer.visible,
                "animation": layer.animation,
                "layer_name": layer.layer_name,
                "z_index": layer.z_index,  # z-indexを含める
            }
            for layer in layers
        ]

        pages_dict[page.page_number] = {
            "layersData": layers_data,
            "textElements": page.text_elements,
            "storyText": page.story_text,
        }

        if page.page_number <= 10 and page.story_text:
            all_story_text += f"\nページ{page.page_number}:\n{page.story_text}\n"

    gemini_question = (
        ask_gemini(all_story_text)
        if all_story_text.strip()
        else "お話が入力されていません。"
    )

    return render_template(
        "read.html",
        book=book,
        pages=pages_dict,
        gemini_question=gemini_question,
        who=book.who,
        where=book.where,
        what=book.what,
    )


# index3ルートを修正
# index3ルートも修正
@app.route("/index3")
def index3():
    book = Book.query.order_by(Book.id.desc()).first()
    pages = Page.query.filter_by(book_id=book.id).all()

    pages_dict = {}

    for page in pages:
        # z-indexの降順に取得
        layers = (
            Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index.desc()).all()
        )
        layers_data = [
            {
                "layer_id": layer.layer_id,
                "canvasData": layer.canvas_data,
                "visible": layer.visible,
                "layer_name": layer.layer_name,
                "animation": layer.animation,
            }
            for layer in layers
        ]
        pages_dict[page.page_number] = {
            "layersData": layers_data,
            "textElements": page.text_elements,
            "storyText": page.story_text,
        }

    return render_template(
        "index3.html",
        book=book,
        pages=pages_dict,
        who=book.who,
        where=book.where,
        what=book.what,
    )


# 本の提出のルート
@app.route("/submit_book", methods=["POST"])
def submit_book():
    book = Book.query.order_by(Book.id.desc()).first()
    book.title = request.form["bookTitle"]
    book.genre = request.form["genre"]
    db.session.commit()
    # summaryページにリダイレクト
    return redirect(url_for("summary"))


# サマリーページのルート
@app.route("/summary")
def summary():
    book = Book.query.order_by(Book.id.desc()).first()
    # index3.htmlテンプレートをレンダリング
    return render_template("index3.html", book_data=book)


# 本の情報取得のルート
@app.route("/get_book_info")
def get_book_info():
    book = Book.query.order_by(Book.id.desc()).first()
    print(f"Found book: {book.title if book else 'None'}")  # デバッグログ

    first_page = Page.query.filter_by(book_id=book.id, page_number=1).first()
    print(f"First page found: {first_page is not None}")  # デバッグログ

    if first_page:
        print(f"Text elements: {first_page.text_elements}")  # デバッグログ

    book_info = {
        "title": book.title,
        "genre": book.genre,
        "first_page_image": (
            first_page.canvas_data if first_page else "/static/placeholder-cover.png"
        ),
        "first_page_text_elements": first_page.text_elements if first_page else "[]",
    }
    return jsonify(book_info)


# ページ情報取得のルート
@app.route("/get_pages")
def get_pages():
    book = Book.query.order_by(Book.id.desc()).first()
    app.logger.debug(f"Getting pages for book: {book.id if book else 'No book found'}")

    if not book:
        return jsonify({})

    pages = Page.query.filter_by(book_id=book.id).all()
    app.logger.debug(f"Found {len(pages)} pages")

    pages_dict = {}
    for page in pages:
        app.logger.debug(
            f"Processing page {page.page_number} with data length: {len(page.canvas_data) if page.canvas_data else 0}"
        )
        pages_dict[page.page_number] = {
            "canvasData": page.canvas_data,
            "textElements": page.text_elements,
        }

    return jsonify(pages_dict)


# 本の詳細ページのルート
@app.route("/book/<title>")
def book_detail(title):
    book = Book.query.filter_by(title=title).first()
    if book is None:
        return "Book not found", 404
    # book_detail.htmlテンプレートをレンダリング
    return render_template("book_detail.html", book_data=book)


# インデックス2ページのルート
@app.route("/index2")
def index2():
    # index2.htmlテンプレートをレンダリング
    return render_template("index2.html")


# 本の情報保存のルート
@app.route("/save_book_info", methods=["POST"])
def save_book_info():
    data = request.json
    book = Book.query.order_by(Book.id.desc()).first()
    if book:
        book.title = data["title"]
        book.genre = data["genre"]
        db.session.commit()
        return jsonify({"status": "success"})
    return jsonify({"status": "error", "message": "Book not found"})


def ask_gemini(story_text):
    """Gemini APIを使って物語の良いところを子供向けに生成する関数"""
    model = genai.GenerativeModel("gemini-1.5-pro-latest")
    prompt = (
        "以下の物語について、小学1年生から4年生向けに、物語の素敵なところを教えてあげてください。先生になったつもりで、やさしい言葉で、子供たちが楽しくなるように説明してくださいね。\n\n"
        "物語本文（ページ1から10まで）:\n" + story_text + "\n\n"
        "説明するときの注意:\n"
        "1.  小学生にもわかる簡単な言葉を使ってください。\n"
        "2.  漢字には、かならずひらがなでふりがなをつけてください。\n"
        "3.  大切なところを強調するときは、「」や『』を使ってください。絶対にアスタリスク(*)は使わないでください。強調にアスタリスクは使用しないでください。\n"
        "4.  短くてわかりやすい文で説明してください。全体で200字以内に収めてください。\n"
        "5.  「すごい！」「よく頑張ったね！」などの励ましの言葉を取り入れてください。\n"
        "6.  箇条書きではなく、自然な文章で書いてください。\n"
        "7.  適切な場所で改行を入れて、読みやすくしてください。\n\n"
        "回答は「このお話の素敵なところは：」から始めて、最後は「このお話、とっても素敵だね！」でしめくくってください。回答は簡潔に、要点だけを伝えてください。"
    )
    try:
        response = model.generate_content([prompt])
        return (
            response.text
            if response and hasattr(response, "text")
            else "AIアドバイスが生成できませんでした。"
        )
    except Exception as e:
        print("⚠️ Gemini API エラー:", e)
        return "AIアドバイスが生成できませんでした。"


@app.route("/ask_gemini", methods=["POST"])
def ask_gemini_endpoint():
    try:
        book = Book.query.order_by(Book.id.desc()).first()
        if not book:
            return jsonify({"question": "お話が見つかりませんでした。"})

        # ページ1～10の文章を収集
        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        all_story_text = ""
        for page in pages:
            if page.page_number <= 10 and page.story_text:
                all_story_text += f"\nページ{page.page_number}:\n{page.story_text}\n"

        if not all_story_text.strip():
            return jsonify({"question": "お話が入力されていません。"})

        answer = ask_gemini(all_story_text)
        return jsonify({"question": answer})
    except Exception as e:
        print("Error in ask_gemini_endpoint:", e)
        return jsonify({"question": "質問の生成中にエラーが発生しました。"})


@app.route("/read/<title>")
def read_book(title):
    book = Book.query.filter_by(title=title).first()
    if book is None:
        return "Book not found", 404

    pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
    pages_data = []
    story_text = ""

    for page in pages:
        # Base64データが正しく保存されているか確認
        if not page.canvas_data.startswith("data:image"):
            app.logger.error(f"Invalid canvas data for page {page.page_number}")
            continue

        pages_data.append(
            {
                "page_number": page.page_number,
                "canvas_data": page.canvas_data,
                "text_elements": (
                    json.loads(page.text_elements) if page.text_elements else []
                ),
            }
        )

        if page.page_number == 1 and page.story_text:
            story_text = page.story_text

    book_data = {
        "title": book.title,
        "genre": book.genre,
        "who": book.who,
        "where": book.where,
        "what": book.what,
        "pages_count": len(pages_data),
        "pages": pages_data,
    }

    app.logger.debug(f"Sending book data with {len(pages_data)} pages")
    return render_template(
        "read.html", book=book_data, story_text=story_text, gemini_question=""
    )


@app.route("/get_all_books")
def get_all_books():
    # 作成された全ての本を取得
    books = Book.query.all()

    # 各本の全ページ情報を含めて返す
    books_info = []
    for book in books:
        # 全ページを取得（ページ番号順）
        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()

        # ページのデータを整理
        pages_data = []
        for page in pages:
            page_info = {
                "page_number": page.page_number,
                "canvas_data": page.canvas_data,
                "text_elements": page.text_elements,
                "story_text": page.story_text,
            }
            pages_data.append(page_info)

        book_info = {
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "pages_count": len(pages),
            "pages": pages_data,
        }
        books_info.append(book_info)

    return jsonify(books_info)


#! ******************************************************************************************************


# complete関数も同様に修正
@app.route("/complete/<int:book_id>")
def complete(book_id):
    book = Book.query.get_or_404(book_id)
    pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
    pages_dict = {}
    all_story_text = ""

    for page in pages:
        # z-indexの降順に取得
        layers = (
            Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index.desc()).all()
        )

        layers_data = [
            {
                "layerId": layer.layer_id,
                "canvasData": layer.canvas_data,
                "visible": layer.visible,
                "animation": layer.animation,
            }
            for layer in layers
        ]

        pages_dict[page.page_number] = {
            "layersData": layers_data,
            "textElements": page.text_elements,
            "storyText": page.story_text,
        }

        if page.page_number <= 10 and page.story_text:
            all_story_text += f"\nページ{page.page_number}:\n{page.story_text}\n"

    gemini_question = (
        ask_gemini(all_story_text)
        if all_story_text.strip()
        else "お話が入力されていません。"
    )

    return render_template(
        "complete.html", book=book, pages=pages_dict, gemini_question=gemini_question
    )


#! ******************************************************************************************************


# allbooksルートも修正
@app.route("/allbooks/<int:book_id>")
def allbooks(book_id):
    book = Book.query.get_or_404(book_id)
    pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
    pages_dict = {}
    all_story_text = ""

    for page in pages:
        # z-indexの降順に取得
        layers = (
            Layer.query.filter_by(page_id=page.id).order_by(Layer.z_index.desc()).all()
        )

        layers_data = [
            {
                "layerId": layer.layer_id,
                "canvasData": layer.canvas_data,
                "visible": layer.visible,
                "animation": layer.animation,
            }
            for layer in layers
        ]

        pages_dict[page.page_number] = {
            "layersData": layers_data,
            "textElements": page.text_elements,
            "storyText": page.story_text,
        }

        if page.page_number <= 10 and page.story_text:
            all_story_text += f"\nページ{page.page_number}:\n{page.story_text}\n"

    gemini_question = (
        ask_gemini(all_story_text)
        if all_story_text.strip()
        else "お話が入力されていません。"
    )

    return render_template(
        "allbooks.html", book=book, pages=pages_dict, gemini_question=gemini_question
    )

    #! ******************************************************************************************************
    # @app.route("/register", methods=["GET", "POST"])
    # def register():
    global current_user
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]

        # サーバーサイドでの検証
        if not (2 <= len(name) <= 20):
            return "名前は2文字以上20文字以下で入力してください", 400

        allowed_domains = ["gmail.com", "yahoo.co.jp", "outlook.com", "outlook.jp"]
        email_domain = email.split("@")[1] if "@" in email else ""
        if email_domain not in allowed_domains:
            return "対応していないメールアドレスです", 400

        if not (8 <= len(password) <= 20):
            return "パスワードは8文字以上20文字以下で入力してください", 400

        # 以降は既存のコード
        code = random.randint(100000, 999999)
        current_user = {
            "name": name,
            "email": email,
            "password": password,
            "code": str(code),
        }
        send_email(email, code)
        return redirect(url_for("verify", email=email))

    return render_template("register.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    global current_user
    if request.method == "POST":
        try:
            # request.form.get()を使用して、キーが存在しない場合はデフォルト値を返す
            name = request.form.get("name", "")
            email = request.form["email"]
            password = request.form["password"]

            # 名前が空の場合はデフォルト値を設定
            if not name:
                name = "新規ユーザー"  # またはメールアドレスの@前の部分を使用

            # メールアドレスの検証
            allowed_domains = ["gmail.com", "yahoo.co.jp", "outlook.com", "outlook.jp"]
            email_parts = email.split("@")
            if len(email_parts) != 2 or email_parts[1] not in allowed_domains:
                return "対応していないメールアドレスです", 400

            # パスワードの検証
            if not (8 <= len(password) <= 20):
                return "パスワードは8文字以上20文字以下で入力してください", 400

            # 認証コードの生成と保存
            code = random.randint(100000, 999999)
            current_user = {
                "name": name,
                "email": email,
                "password": password,
                "code": str(code),
            }

            # 認証メールの送信
            send_email(email, code)

            # 認証ページへリダイレクト
            return redirect(url_for("verify", email=email))
        except Exception as e:
            # エラーログ出力
            app.logger.error(f"Registration error: {e}")
            return f"登録処理中にエラーが発生しました: {e}", 500

    # GETリクエストの場合は登録フォームを表示
    return render_template("register.html")


@app.route("/verify", methods=["GET", "POST"])
def verify():
    global current_user
    email = request.args.get("email")
    if request.method == "POST":
        input_code = request.form["code"]
        if input_code == current_user.get("code"):
            name = current_user.get("name")
            email = current_user.get("email")
            password = current_user.get("password")
            new_user = User(name=name, email=email, password=password)
            db.session.add(new_user)
            db.session.commit()
            current_user = {
                "id": new_user.id,
                "name": new_user.name,
                "email": new_user.email,
            }
            return redirect(url_for("home_page"))
        else:
            return "無効なコードです。もう一度お試しください。"
    return render_template("verify.html", email=email)


@app.route("/login")
def login():
    # 直接ログインページを表示するだけに変更
    return redirect(url_for("login_page"))


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


def send_email(to_email, code):
    from_email = "palettebook01@gmail.com"
    from_password = "qxdj kgkx ddjf mtmf"
    subject = "認証コード"
    body = f"あなたの認証コードは {code} です"

    msg = MIMEMultipart()
    msg["From"] = from_email
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        print("SMTPサーバーに接続中...")
        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        print("ログイン中...")
        server.login(from_email, from_password)
        print("メール送信中...")
        server.sendmail(from_email, to_email, msg.as_string())
        server.close()
        print("メールが正常に送信されました")
    except smtplib.SMTPAuthenticationError:
        print("SMTP認証エラー: メールアドレスまたはパスワードが正しくありません")
    except smtplib.SMTPConnectError:
        print("SMTP接続エラー: サーバーに接続できませんでした")
    except smtplib.SMTPException as e:
        print(f"SMTPエラーが発生しました: {e}")
    except Exception as e:
        print(f"予期しないエラーが発生しました: {e}")


@app.route("/book_list")
def book_list():
    user = session.get("user")
    if not user:
        return redirect(url_for("login"))

    # Use the same logic as home_page() to get books
    profile_name = session.get("selected_profile_name")

    if not profile_name or profile_name == "未定":
        profile = (
            Profile.query.filter_by(user_id=user["id"])
            .order_by(Profile.id.desc())
            .first()
        )
        if profile:
            profile_name = profile.name
        else:
            profile_name = "未定"

    books = (
        Book.query.filter_by(author_name=profile_name).order_by(Book.id.desc()).all()
        if profile_name != "未定"
        else []
    )
    books_data = []

    for book in books:
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_dict = {}

        for page in pages:
            layers = Layer.query.filter_by(page_id=page.id).all()
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                }
                for layer in layers
            ]

            pages_dict[page.page_number] = {
                "layersData": layers_data,
                "textElements": page.text_elements,
                "storyText": page.story_text,
            }

        books_data.append({"book": book_dict, "pages": pages_dict})

    return render_template("book_list.html", books=books_data, name=profile_name)


@app.route("/gallery")
def gallery():
    books = Book.query.order_by(Book.id.desc()).all()
    books_by_genre = defaultdict(list)

    for book in books:
        book_dict = {
            "id": book.id,
            "title": book.title,
            "genre": book.genre,
            "who": book.who,
            "where": book.where,
            "what": book.what,
            "author_name": book.author_name,
        }

        pages = Page.query.filter_by(book_id=book.id).order_by(Page.page_number).all()
        pages_dict = {}

        for page in pages:
            layers = Layer.query.filter_by(page_id=page.id).all()
            layers_data = [
                {
                    "layerId": layer.layer_id,
                    "canvasData": layer.canvas_data,
                    "visible": layer.visible,
                    "animation": layer.animation,
                }
                for layer in layers
            ]

            pages_dict[page.page_number] = {
                "layersData": layers_data,
                "textElements": page.text_elements,
                "storyText": page.story_text,
            }

        book_dict["pages"] = pages_dict
        books_by_genre[book.genre].append(book_dict)

    return render_template("gallery.html", books_by_genre=books_by_genre)


@app.before_request
def make_session_permanent():
    session.permanent = True


#! ******************************************************************************************************


@app.route("/delete_book/<int:book_id>", methods=["POST"])
def delete_book(book_id):
    book = Book.query.get(book_id)
    if not book:
        return jsonify({"status": "error", "message": "Book not found"}), 404

    try:
        # 本に関連するページとレイヤーを削除
        pages = Page.query.filter_by(book_id=book.id).all()
        for page in pages:
            Layer.query.filter_by(
                page_id=page.id
            ).delete()  # ページに関連するレイヤーを削除
            db.session.delete(page)  # ページを削除

        db.session.delete(book)  # 本を削除
        db.session.commit()
        return jsonify({"status": "success"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500


#! ******************************************************************************************************
@app.route("/get_current_profile")
def get_current_profile():
    global current_user
    if not current_user or "selected_profile_name" not in current_user:
        return jsonify({"has_profile": False})
    return jsonify({"has_profile": True})


#! ******************************************************************************************************


@app.route("/get_avatars")
def get_avatars():
    avatar_dir = "static/avatars"  # アバター画像のディレクトリ
    avatars = [
        f for f in os.listdir(avatar_dir) if f.endswith(".png") or f.endswith(".jpg")
    ]
    return jsonify(avatars)


#! ******************************************************************************************************


@app.route("/update_avatar/<int:profile_id>", methods=["POST"])
def update_avatar(profile_id):
    """
    プロフィールのアバターを更新するAPIエンドポイント。
    フロントエンドから新しいアバターのファイル名を受け取り、
    データベースの `profiles` テーブルを更新する。
    """
    global current_user
    if not current_user:
        return jsonify({"success": False, "message": "ログインしてください。"})

    # リクエストのJSONデータを取得
    data = request.json
    new_avatar = data.get("avatar")

    # プロフィールを検索
    profile = Profile.query.filter_by(id=profile_id, user_id=current_user["id"]).first()

    if profile:
        # アバターを更新
        profile.avatar = new_avatar
        db.session.commit()
        print(
            f"✅ アバター更新成功: プロフィールID {profile_id} → {new_avatar}"
        )  # ログ出力
        return jsonify({"success": True})
    else:
        print(
            f"⚠️ アバター更新失敗: プロフィールID {profile_id} が見つかりません"
        )  # エラーログ
        return jsonify({"success": False, "message": "プロフィールが見つかりません。"})


#! ******************************************************************************************************


# アプリケーションのエントリーポイント
if __name__ == "__main__":
    # app.run(debug=True)
    app.run(host="0.0.0.0", port=5001, debug=True)
